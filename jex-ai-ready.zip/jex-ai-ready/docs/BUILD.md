# Building Jex AI

1. Install the latest stable Android Studio (AGP 9.0.1 needs a recent one) and JDK 17+.
2. Open this folder. Android Studio creates `gradle-wrapper.jar` and syncs (Gradle 9.1.0).
3. Pick a build variant: `directDebug` (full phone control) or `playDebug` (Play-safe).
4. Run on a real phone (voice, camera and WebGL need real hardware).
5. In the app: Settings > Gemini API key > paste your key from https://aistudio.google.com/apikey

## Things you may need to adjust (could not be verified offline)
* `GeminiLiveClient.MODEL` is one constant. Check the Live API docs for the current model name.
* Three.js for the Forge 3D scene: see `app/src/main/assets/forge/README.txt`. Without it the Canvas fallback scene is used.
* Fonts: see `ui/theme/Type.kt` (system serif/sans are used until you drop the font files in `res/font`).
* Legacy product names: list them in `app/old-names.txt` (one per line) and `NoOldNameTest` enforces they never appear.

## Release signing
Copy `keystore.properties.example` to `keystore.properties`, fill it in, run `./gradlew assembleDirectRelease` or `bundlePlayRelease`.

## Play Store
Use the `play` flavor only. It has no Accessibility service, no notification listener, no overlay, no `QUERY_ALL_PACKAGES`,
and never sends a message without the user tapping Send.
