Open this folder in Android Studio (latest stable). It will create gradle-wrapper.jar for you.
Or run once:  gradle wrapper --gradle-version 9.1.0
