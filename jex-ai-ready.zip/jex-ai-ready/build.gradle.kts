// Top-level build file. AGP 9 compiles Kotlin natively (built-in Kotlin), so the
// org.jetbrains.kotlin.android plugin must NOT be applied.
plugins {
    id("com.android.application") version "9.0.1" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.10" apply false
}
