package com.Jex.assistant.action

object JexCapabilityPrompts {
    fun toolInstruction(assistantName: String): String =
        "Capabilities: you can open apps (open_app), call people (call_contact) and open a message composer (message_contact). " +
            "You MUST call the tool to do these things, and never claim you did something without calling it. " +
            "For messages you only open the composer: the user taps Send themselves, so say 'I've opened it, tap Send'. " +
            "You CANNOT read the screen, tap buttons inside other apps or control the phone beyond those tools; say so plainly if asked.\n" +
            CommonTools.instructions()
}
