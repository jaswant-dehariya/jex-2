// Jex Forge: a 3D "workshop" scene driven by the Android side via window.forge.setState(...).
// Requires three.module.min.js (three r16x, core only) next to this file. If it is missing or WebGL is
// unavailable we tell the app (ForgeJsBridge.onFallback) and it shows a Canvas fallback instead.
const bridge = window.ForgeJsBridge || { onReady() {}, onFallback() {}, onLog() {} };
const STAGE_COLORS = [0x8b5cf6, 0x3fe0d0, 0xff6fae, 0xffb547, 0xff8a3d, 0xffe2b0, 0x3fe0d0];

async function boot() {
  let THREE;
  try {
    THREE = await import('./three.module.min.js');
    const test = document.createElement('canvas');
    if (!(test.getContext('webgl2') || test.getContext('webgl'))) throw new Error('no webgl');
  } catch (e) {
    bridge.onFallback();
    return;
  }

  const canvas = document.getElementById('c');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 100);
  camera.position.set(0, 0.6, 7);

  scene.add(new THREE.AmbientLight(0xffffff, 0.5));
  const key = new THREE.PointLight(0xffffff, 40, 30); key.position.set(3, 4, 5); scene.add(key);
  const rim = new THREE.PointLight(0xff6fae, 30, 30); rim.position.set(-4, -2, 3); scene.add(rim);

  // core
  const coreMat = new THREE.MeshStandardMaterial({ color: 0x8b5cf6, emissive: 0x8b5cf6, emissiveIntensity: 0.8, roughness: 0.25, metalness: 0.4, flatShading: true });
  const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1.1, 1), coreMat);
  scene.add(core);
  const wire = new THREE.Mesh(new THREE.IcosahedronGeometry(1.45, 1), new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.25 }));
  scene.add(wire);

  // particle halo
  const N = 700;
  const pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) {
    const r = 2.2 + Math.random() * 2.6, a = Math.random() * Math.PI * 2, y = (Math.random() - 0.5) * 3.2;
    pos[i * 3] = Math.cos(a) * r; pos[i * 3 + 1] = y; pos[i * 3 + 2] = Math.sin(a) * r;
  }
  const pg = new THREE.BufferGeometry();
  pg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const pm = new THREE.PointsMaterial({ color: 0xffffff, size: 0.04, transparent: true, opacity: 0.8 });
  const points = new THREE.Points(pg, pm);
  scene.add(points);

  // progress ring
  const ringGroup = new THREE.Group(); scene.add(ringGroup);
  const ringMat = new THREE.MeshBasicMaterial({ color: 0xffb547 });
  let ringMesh = null;
  function setRing(p) {
    if (ringMesh) { ringGroup.remove(ringMesh); ringMesh.geometry.dispose(); }
    const arc = Math.max(0.02, Math.min(1, p)) * Math.PI * 2;
    ringMesh = new THREE.Mesh(new THREE.TorusGeometry(2.0, 0.03, 8, 120, arc), ringMat);
    ringMesh.rotation.x = Math.PI / 2.4;
    ringGroup.add(ringMesh);
  }
  setRing(0.02);

  // one slab per finished section
  const slabs = [];
  function syncSlabs(names) {
    while (slabs.length < names.length) {
      const i = slabs.length;
      const m = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.9, 0.08),
        new THREE.MeshStandardMaterial({ color: STAGE_COLORS[i % STAGE_COLORS.length], emissive: STAGE_COLORS[i % STAGE_COLORS.length], emissiveIntensity: 0.35, roughness: 0.4 }));
      m.userData = { born: performance.now(), i };
      scene.add(m); slabs.push(m);
    }
    while (slabs.length > names.length) { const m = slabs.pop(); scene.remove(m); m.geometry.dispose(); m.material.dispose(); }
  }

  let state = { stage: 0, progress: 0, sections: [], phase: 'BUILDING' };
  let targetColor = new THREE.Color(STAGE_COLORS[0]);
  window.forge = {
    setState(s) {
      state = Object.assign(state, s);
      targetColor = new THREE.Color(STAGE_COLORS[Math.max(0, Math.min(6, state.stage | 0))]);
      setRing(state.progress || 0.02);
      syncSlabs(state.sections || []);
    }
  };

  function resize() {
    const w = canvas.clientWidth || window.innerWidth, h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h; camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize); resize();

  let px = 0, py = 0;
  canvas.addEventListener('pointermove', (e) => { px = (e.clientX / canvas.clientWidth - 0.5) * 2; py = (e.clientY / canvas.clientHeight - 0.5) * 2; });
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const clock = new THREE.Clock();
  function frame() {
    const t = clock.getElapsedTime();
    const speed = reduce ? 0.1 : (state.phase === 'DONE' ? 0.4 : 1);
    core.rotation.y = t * 0.5 * speed; core.rotation.x = t * 0.25 * speed;
    wire.rotation.y = -t * 0.3 * speed;
    const s = 1 + Math.sin(t * 2) * 0.03 * speed;
    core.scale.setScalar(s);
    coreMat.color.lerp(targetColor, 0.06); coreMat.emissive.lerp(targetColor, 0.06);
    points.rotation.y = t * 0.05 * speed;
    ringGroup.rotation.z = t * 0.2 * speed;
    const n = slabs.length;
    slabs.forEach((m, i) => {
      const a = t * 0.25 * speed + (i / Math.max(n, 1)) * Math.PI * 2;
      const age = Math.min(1, (performance.now() - m.userData.born) / 700);
      const R = 3.1 * age;
      m.position.set(Math.cos(a) * R, Math.sin(t * 0.8 + i) * 0.25 + (i % 2 ? 0.6 : -0.6), Math.sin(a) * R);
      m.lookAt(0, m.position.y, 0);
      m.scale.setScalar(age);
    });
    camera.position.x += (px * 0.8 - camera.position.x) * 0.04;
    camera.position.y += (0.6 - py * 0.5 - camera.position.y) * 0.04;
    camera.lookAt(0, 0, 0);
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  frame();
  bridge.onReady();
}
boot();
