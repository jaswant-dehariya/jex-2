Jex Forge 3D scene
==================
forge.js needs Three.js (core, ES module build) in this folder:

  three.module.min.js        (from https://unpkg.com/three@0.160.0/build/three.module.min.js)

In recent Three.js versions three.module.min.js imports ./three.core.min.js too; if you use such a version,
copy BOTH files here. Without them the app still works: the Forge shows its built-in Canvas fallback scene.
