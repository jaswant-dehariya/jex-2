package com.Jex.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.assistantSettings by preferencesDataStore(name = "assistant_settings")

/** Pure fallback rules, unit-tested without Android. */
object SettingFallbacks {
    fun resolve(dataStoreValue: String?, prefsValue: String?, default: String): String =
        dataStoreValue?.takeIf { it.isNotBlank() }
            ?: prefsValue?.takeIf { it.isNotBlank() }
            ?: default
}

object PersonalityRepository {
    private val K_PERSONALITY = stringPreferencesKey("personality")
    private val K_LANGUAGE = stringPreferencesKey("language")
    private val K_ASSISTANT_NAME = stringPreferencesKey("assistant_name")
    private val K_VOICE = stringPreferencesKey("voice_name")

    const val DEFAULT_VOICE = "Aoede"

    private fun store(ctx: Context) = ctx.applicationContext.assistantSettings

    fun personality(ctx: Context): Flow<Personality> = store(ctx).data.map {
        Personality.fromName(
            SettingFallbacks.resolve(
                it[K_PERSONALITY],
                JexPreferences.getString(ctx, JexPreferences.Keys.PERSONALITY),
                Personality.DEFAULT.name
            )
        )
    }

    fun language(ctx: Context): Flow<LanguagePreference> = store(ctx).data.map {
        LanguagePreference.fromName(
            SettingFallbacks.resolve(
                it[K_LANGUAGE],
                JexPreferences.getString(ctx, JexPreferences.Keys.LANGUAGE),
                LanguagePreference.AUTO.name
            )
        )
    }

    fun assistantName(ctx: Context): Flow<String> = store(ctx).data.map {
        SettingFallbacks.resolve(
            it[K_ASSISTANT_NAME],
            JexPreferences.getString(ctx, JexPreferences.Keys.ASSISTANT_NAME),
            AssistantBrand.NAME
        )
    }

    fun voiceName(ctx: Context): Flow<String> = store(ctx).data.map {
        SettingFallbacks.resolve(
            it[K_VOICE],
            JexPreferences.getString(ctx, JexPreferences.Keys.VOICE_NAME),
            DEFAULT_VOICE
        )
    }

    suspend fun getPersonality(ctx: Context): Personality = personality(ctx).first()
    suspend fun getLanguage(ctx: Context): LanguagePreference = language(ctx).first()
    suspend fun getAssistantName(ctx: Context): String = assistantName(ctx).first()
    suspend fun getVoiceName(ctx: Context): String = voiceName(ctx).first()

    suspend fun setPersonality(ctx: Context, value: Personality) {
        store(ctx).edit { it[K_PERSONALITY] = value.name }
        JexPreferences.putString(ctx, JexPreferences.Keys.PERSONALITY, value.name)
        VoiceSessionManager.refreshInstructions(ctx)
    }

    suspend fun setLanguage(ctx: Context, value: LanguagePreference) {
        store(ctx).edit { it[K_LANGUAGE] = value.name }
        JexPreferences.putString(ctx, JexPreferences.Keys.LANGUAGE, value.name)
        VoiceSessionManager.refreshInstructions(ctx)
    }

    suspend fun setAssistantName(ctx: Context, value: String) {
        val clean = value.trim().ifBlank { AssistantBrand.NAME }
        store(ctx).edit { it[K_ASSISTANT_NAME] = clean }
        JexPreferences.putString(ctx, JexPreferences.Keys.ASSISTANT_NAME, clean)
        VoiceSessionManager.refreshInstructions(ctx)
    }

    suspend fun setVoiceName(ctx: Context, value: String) {
        store(ctx).edit { it[K_VOICE] = value }
        JexPreferences.putString(ctx, JexPreferences.Keys.VOICE_NAME, value)
        VoiceSessionManager.refreshInstructions(ctx)
    }
}
