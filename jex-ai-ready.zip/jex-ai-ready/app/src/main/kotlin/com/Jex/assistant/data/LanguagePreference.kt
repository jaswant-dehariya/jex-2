package com.Jex.assistant.data

enum class LanguagePreference(val displayName: String, val description: String) {
    AUTO("Auto", "Follows whatever you speak"),
    HINDI("हिन्दी", "Always answers in Hindi"),
    HINGLISH("Hinglish", "Hindi written in English letters"),
    ENGLISH("English", "Always answers in English");

    companion object {
        fun fromName(name: String?): LanguagePreference =
            entries.firstOrNull { it.name == name } ?: AUTO
    }
}

enum class ThemeMode(val displayName: String) {
    DARK("Dark"), LIGHT("Light"), SYSTEM("System");

    companion object {
        fun fromName(name: String?): ThemeMode = entries.firstOrNull { it.name == name } ?: DARK
    }
}
