package com.Jex.assistant.license

data class LicenseInfo(
    val active: Boolean = true,
    val plan: String = "",
    val expiresAt: Long = 0L,
    val statusText: String = "",
    val blocked: Boolean = false,
    val hasRememberedKey: Boolean = false
)
