package com.Jex.assistant.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.Jex.assistant.data.ApiKeyStore
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.ui.components.JexButton
import com.Jex.assistant.ui.components.JexVoiceVisualizer
import com.Jex.assistant.ui.fx.JexOrb3D
import com.Jex.assistant.ui.nav.Routes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.MinTouchTarget
import com.Jex.assistant.ui.theme.depthSurface
import com.Jex.assistant.voice.JexOrbState
import com.Jex.assistant.voice.VoiceForegroundService
import com.Jex.assistant.voice.VoiceSessionManager

@Composable
fun VoiceScreen(appState: JexAppState, nav: NavHostController) {
    val ctx = LocalContext.current
    val c = LocalJexColors.current
    val state by VoiceSessionManager.state.collectAsState()
    val amp by VoiceSessionManager.amplitude.collectAsState()
    val status by VoiceSessionManager.statusText.collectAsState()
    val muted by VoiceSessionManager.muted.collectAsState()
    val active by VoiceSessionManager.isActive.collectAsState()
    val error by VoiceSessionManager.lastError.collectAsState()
    val hasKey = ApiKeyStore.hasKey(ctx)

    fun micGranted() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    var hasMic by remember { mutableStateOf(micGranted()) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasMic = micGranted()
        if (hasMic && hasKey) VoiceForegroundService.start(ctx)
    }
    val perms = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    // Start once on entry. The service is NOT stopped when this screen leaves composition.
    LaunchedEffect(hasKey, hasMic) {
        if (hasKey && hasMic && !VoiceSessionManager.isActive.value) VoiceForegroundService.start(ctx)
        else if (hasKey && !hasMic) launcher.launch(perms)
    }

    val needsAction = !hasKey || !hasMic
    val shownState = if (needsAction) JexOrbState.ERROR else state
    val statusLine = when {
        !hasKey -> "I need your Gemini API key first."
        !hasMic -> "I need microphone permission to listen."
        state == JexOrbState.ERROR && error != null -> error ?: status
        else -> "${appState.assistantName} · $status"
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val orb = maxWidth * 0.7f
                Box(contentAlignment = Alignment.Center) {
                    JexVoiceVisualizer(amp, state == JexOrbState.SPEAKING, Modifier.size(orb * 1.35f))
                    JexOrb3D(shownState, orb, amp, style = appState.orbStyle)
                }
            }
            Text(
                statusLine, style = JexType.voice.copy(color = if (shownState == JexOrbState.ERROR) c.error else c.textSecondary),
                textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp).semantics { contentDescription = statusLine }
            )
            Spacer(Modifier.height(16.dp))
            FlavorVoiceExtras(appState, nav)
            Spacer(Modifier.height(16.dp))
            if (!hasKey) {
                JexButton("Open Settings", { nav.navigate(Routes.SETTINGS) })
            } else if (!hasMic) {
                JexButton("Allow microphone", { launcher.launch(perms) })
            } else {
                Row(
                    Modifier.padding(horizontal = 24.dp).depthSurface(c, androidx.compose.foundation.shape.RoundedCornerShape(36.dp), 8.dp)
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    RoundControl(if (muted) Icons.Filled.MicOff else Icons.Filled.Mic, if (muted) "Unmute" else "Mute", 56, c.textPrimary) {
                        VoiceSessionManager.toggleMute()
                    }
                    RoundControl(Icons.Filled.Stop, "Stop", 72, c.error) {
                        VoiceForegroundService.stop(ctx)
                        nav.popBackStack()
                    }
                    RoundControl(Icons.Filled.Videocam, "Vision", 56, c.textPrimary) { nav.navigate(Routes.VISION) }
                    RoundControl(Icons.Filled.Close, "Close", 56, c.textPrimary) { nav.popBackStack() }
                }
            }
        }
    }
}

@Composable
private fun RoundControl(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, size: Int, tint: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    val c = LocalJexColors.current
    Box(
        Modifier.size(maxOf(size, 48).dp).clip(CircleShape).background(tint.copy(alpha = 0.14f), CircleShape)
            .clickable(onClick = onClick).semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { Icon(icon, label, tint = tint, modifier = Modifier.size((size / 2).dp)) }
}
