package com.Jex.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.ui.components.JexEmptyState
import com.Jex.assistant.ui.components.JexGlassCard
import com.Jex.assistant.ui.components.JexTextField
import com.Jex.assistant.ui.components.JexTopBar
import com.Jex.assistant.ui.fx.JexCanvasOrb
import com.Jex.assistant.ui.fx.JexOrbStyle
import com.Jex.assistant.ui.nav.Routes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalBottomBarInset
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.MinTouchTarget
import com.Jex.assistant.voice.JexOrbState
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(appState: JexAppState, nav: NavHostController) {
    val c = LocalJexColors.current
    var query by remember { mutableStateOf("") }
    val inset = LocalBottomBarInset.current
    val list = appState.conversations.filter {
        query.isBlank() || it.title.contains(query, true) || it.messages.any { m -> m.text.contains(query, true) }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        JexTopBar("History")
        JexTextField(query, { query = it }, "Search conversations", Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        if (list.isEmpty()) {
            JexEmptyState(
                "No conversations yet", "Start a chat and it will show up here.",
                buttonText = "Start chatting", onButton = { nav.navigate(Routes.CHAT) },
                visual = { JexCanvasOrb(JexOrbState.IDLE, JexOrbStyle.MINIMAL, 96.dp, 0f) }
            )
        } else {
            LazyColumn(
                Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 16.dp, end = 16.dp, top = 8.dp, bottom = inset.calculateBottomPadding() + 16.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(list, key = { it.id }) { conv ->
                    JexGlassCard(Modifier.fillMaxWidth(), onClick = {
                        ChatSession.pendingConversationId = conv.id
                        nav.navigate(Routes.CHAT)
                    }) {
                        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(conv.title, style = JexType.title.copy(color = c.textPrimary), maxLines = 1)
                                Text(
                                    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(conv.updatedAt)) +
                                        " · ${conv.messages.size} messages",
                                    style = JexType.caption.copy(color = c.textSecondary)
                                )
                            }
                            IconButton(onClick = { appState.deleteConversation(conv.id) }, Modifier.size(MinTouchTarget)) {
                                Icon(Icons.Filled.Delete, "Delete conversation", tint = c.textTertiary)
                            }
                        }
                    }
                }
            }
        }
    }
}
