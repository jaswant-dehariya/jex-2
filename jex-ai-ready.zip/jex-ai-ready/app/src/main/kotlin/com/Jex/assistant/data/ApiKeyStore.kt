package com.Jex.assistant.data

import android.content.Context

/** The Gemini key is typed by the user in Settings and stored only on this device. Never logged. */
object ApiKeyStore {
    private const val FILE = "jex_prefs"
    private const val KEY = "gemini_api_key"

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getKey(ctx: Context): String = prefs(ctx).getString(KEY, "")?.trim().orEmpty()

    fun saveKey(ctx: Context, key: String) {
        prefs(ctx).edit().putString(KEY, key.trim()).apply()
    }

    fun hasKey(ctx: Context): Boolean = getKey(ctx).isNotBlank()
}
