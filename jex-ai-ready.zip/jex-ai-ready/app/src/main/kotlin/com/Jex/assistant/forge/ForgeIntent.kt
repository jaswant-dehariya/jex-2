package com.Jex.assistant.forge

/** Detects a typed "build me a website" request. Needs a subject AND a build verb; ignores questions. */
object ForgeIntent {
    private val subject = Regex(
        "(website|web site|webpage|web page|landing page|portfolio site|\\bsite\\b|वेबसाइट)", RegexOption.IGNORE_CASE
    )
    private val verb = Regex(
        "(\\bbuild\\b|\\bcreate\\b|\\bmake\\b|\\bdesign\\b|\\bgenerate\\b|\\bbana\\b|\\bbanao\\b|\\bbanana\\b|\\bbanado\\b|\\bbnao\\b|बनाओ|बना)",
        RegexOption.IGNORE_CASE
    )
    private val questionStart = Regex(
        "^(how|what|why|when|which|who|is|are|does|do|kya|kaise|kyun|kyu|kab)\\b", RegexOption.IGNORE_CASE
    )

    /** Returns the website request text, or null when this is not a Forge request. */
    fun extract(text: String): String? {
        val t = text.trim()
        if (t.length < 6) return null
        if (!subject.containsMatchIn(t) || !verb.containsMatchIn(t)) return null
        if (questionStart.containsMatchIn(t) && t.endsWith("?")) return null
        return t
    }
}
