package com.Jex.assistant.vision

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.provider.MediaStore
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

enum class VisionCamera { BACK, FRONT }

data class VisionUiState(val active: Boolean = false, val camera: VisionCamera = VisionCamera.BACK, val error: String? = null)

/** CameraX owner for Vision Mode. Frames go to the live model at ~1 fps (adaptive); under backpressure old frames are dropped. */
object VisionController {
    private val _state = MutableStateFlow(VisionUiState())
    val state: StateFlow<VisionUiState> = _state

    private val _pendingOpen = MutableStateFlow(false)
    val pendingOpen: StateFlow<Boolean> = _pendingOpen
    fun requestOpen() { _pendingOpen.value = true }
    fun consumePendingOpen() { _pendingOpen.value = false }

    private val analysisExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "jex-vision").also { it.isDaemon = true } }
    private var provider: ProcessCameraProvider? = null
    private var preview: Preview? = null
    private var analysis: ImageAnalysis? = null
    private var capture: ImageCapture? = null
    private var camera: Camera? = null

    @Volatile private var lastFrame: ByteArray? = null
    @Volatile private var lastSentMs = 0L
    @Volatile private var intervalMs = 1000L

    fun lastFrameJpeg(): ByteArray? = lastFrame

    /** Binds the camera to [owner]. [previewView] is null when running without a visible preview (background). */
    fun bind(ctx: Context, owner: LifecycleOwner, previewView: PreviewView?, camera: VisionCamera = _state.value.camera, onError: (String) -> Unit = {}) {
        val app = ctx.applicationContext
        val future = ProcessCameraProvider.getInstance(app)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                p.unbindAll()
                val selector = if (camera == VisionCamera.FRONT) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                val useCases = mutableListOf<androidx.camera.core.UseCase>()
                if (previewView != null) {
                    preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider); useCases += it }
                } else preview = null
                analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build().also {
                        it.setAnalyzer(analysisExecutor) { image ->
                            try { handleFrame(image) } finally { image.close() }
                        }
                        useCases += it
                    }
                capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build().also { useCases += it }
                this.camera = p.bindToLifecycle(owner, selector, *useCases.toTypedArray())
                FrameSourceArbiter.start(FrameSourceArbiter.Source.VISION, keepOther = FrameSourceArbiter.isRunning(FrameSourceArbiter.Source.SCREEN) && false)
                _state.value = VisionUiState(true, camera, null)
            } catch (e: Exception) {
                val msg = "Couldn't start the camera."
                _state.value = VisionUiState(false, camera, msg)
                onError(msg)
            }
        }, ContextCompat.getMainExecutor(app))
    }

    private fun handleFrame(image: androidx.camera.core.ImageProxy) {
        val now = System.currentTimeMillis()
        if (!FrameMath.shouldSend(now, lastSentMs, intervalMs)) return
        if (!VoiceSessionManager.isLive) return
        val bmp = try { image.toBitmap() } catch (ignored: Exception) { return }
        val jpeg = encode(bmp, image.imageInfo.rotationDegrees, 768, 65)
        lastFrame = jpeg
        lastSentMs = now
        if (FrameSourceArbiter.allowed(FrameSourceArbiter.Source.VISION)) {
            VoiceSessionManager.sendVideoFrame(jpeg)
        }
    }

    /** rotate -> downscale (long edge) -> JPEG. Recycles bitmaps. */
    fun encode(src: Bitmap, rotationDeg: Int, longEdge: Int, quality: Int): ByteArray {
        var bmp = src
        val rot = FrameMath.normalizeRotation(rotationDeg)
        if (rot != 0) {
            val m = Matrix().apply { postRotate(rot.toFloat()) }
            val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (rotated !== bmp) bmp.recycle()
            bmp = rotated
        }
        val (w, h) = FrameMath.scaledSize(bmp.width, bmp.height, longEdge)
        if (w != bmp.width || h != bmp.height) {
            val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
            if (scaled !== bmp) bmp.recycle()
            bmp = scaled
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
        bmp.recycle()
        return out.toByteArray()
    }

    fun switchCamera(ctx: Context, owner: LifecycleOwner, previewView: PreviewView?) {
        val next = if (_state.value.camera == VisionCamera.BACK) VisionCamera.FRONT else VisionCamera.BACK
        bind(ctx, owner, previewView, next)
    }

    fun stop() {
        try { analysis?.clearAnalyzer() } catch (ignored: Exception) {}
        try { provider?.unbindAll() } catch (ignored: Exception) {}
        analysis = null; preview = null; capture = null; camera = null
        lastFrame = null
        FrameSourceArbiter.stop(FrameSourceArbiter.Source.VISION)
        _state.value = VisionUiState(false, _state.value.camera, null)
    }

    /** Saves a photo to Pictures/Jex via MediaStore and returns its URI string, or null on failure. */
    suspend fun takePhoto(ctx: Context): String? {
        val cap = capture ?: return null
        val app = ctx.applicationContext
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "jex_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Jex")
        }
        val opts = ImageCapture.OutputFileOptions.Builder(app.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        return suspendCancellableCoroutine { cont ->
            cap.takePicture(opts, ContextCompat.getMainExecutor(app), object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) { if (cont.isActive) cont.resume(r.savedUri?.toString()) }
                override fun onError(e: ImageCaptureException) { if (cont.isActive) cont.resume(null) }
            })
        }
    }
}
