package com.Jex.assistant.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.Jex.assistant.data.AssistantBrand
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.ui.components.JexButton
import com.Jex.assistant.ui.components.JexButtonStyle
import com.Jex.assistant.ui.fx.JexOrb3D
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.voice.JexOrbState
import kotlinx.coroutines.launch

private data class OnbPage(val title: String, val body: String, val state: JexOrbState)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(appState: JexAppState, onDone: () -> Unit) {
    val c = LocalJexColors.current
    val pages = listOf(
        OnbPage("Meet ${AssistantBrand.FULL_NAME}", "Your voice-first companion. ${AssistantBrand.CREDIT_LINE}.", JexOrbState.IDLE),
        OnbPage("Talk in your own language", "Hindi, Hinglish or English. Interrupt any time, I keep up.", JexOrbState.LISTENING),
        OnbPage("Two minds, one voice", "Ten personalities, voice and typed chat, and a website builder you can watch in 3D.", JexOrbState.SPEAKING),
        OnbPage("You stay in control", "Add your Gemini key in Settings. It stays on your phone. I ask before anything irreversible.", JexOrbState.THINKING)
    )
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.End) {
            JexButton("Skip", onDone, style = JexButtonStyle.TEXT)
        }
        HorizontalPager(pager, Modifier.weight(1f)) { i ->
            val p = pages[i]
            val offset = (pager.currentPage - i) + pager.currentPageOffsetFraction
            Column(
                Modifier.fillMaxSize().padding(32.dp).graphicsLayer { translationX = offset * size.width * 0.4f },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                JexOrb3D(p.state, (180 + i * 10).dp, 0.1f, style = appState.orbStyle)
                Spacer(Modifier.height(32.dp))
                Text(p.title, style = JexType.headline.copy(color = c.textPrimary), textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(p.body, style = JexType.body.copy(color = c.textSecondary), textAlign = TextAlign.Center)
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.Center) {
            repeat(pages.size) { i ->
                Box(Modifier.padding(4.dp).size(8.dp).background(if (i == pager.currentPage) c.accent else c.textTertiary, CircleShape))
            }
        }
        JexButton(
            if (pager.currentPage == pages.lastIndex) "Get started" else "Next",
            {
                if (pager.currentPage == pages.lastIndex) onDone()
                else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
            },
            Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 16.dp)
        )
    }
}
