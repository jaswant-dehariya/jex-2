package com.Jex.assistant.action

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import java.net.URLEncoder

object CommIntents {
    const val WA = "com.whatsapp"
    const val WA_BUSINESS = "com.whatsapp.w4b"

    fun digits(number: String): String = number.filter { it.isDigit() }

    fun whatsAppPackage(ctx: Context): String? = listOf(WA, WA_BUSINESS).firstOrNull { isInstalled(ctx, it) }

    fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (ignored: Exception) { false }

    fun whatsAppUrl(number: String, text: String): String =
        "https://wa.me/${digits(number)}?text=" + URLEncoder.encode(text, "UTF-8").replace("+", "%20")

    /** Returns "calling" or "dialer_opened_no_permission" or "failed". */
    fun call(ctx: Context, number: String): String {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val uri = Uri.parse("tel:" + Uri.encode(number))
        return try {
            val i = Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            if (granted) "calling" else "dialer_opened_no_permission"
        } catch (ignored: Exception) { "failed" }
    }

    fun openSmsComposer(ctx: Context, number: String, text: String): Boolean = try {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)))
            .putExtra("sms_body", text).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i); true
    } catch (ignored: Exception) { false }

    fun openWhatsAppComposer(ctx: Context, number: String, text: String): Boolean = try {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(whatsAppUrl(number, text))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        whatsAppPackage(ctx)?.let { i.setPackage(it) }
        ctx.startActivity(i); true
    } catch (ignored: Exception) { false }
}
