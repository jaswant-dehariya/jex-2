package com.Jex.assistant.vision

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.Jex.assistant.MainActivity
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.action.functionDecl
import com.Jex.assistant.voice.VoiceSessionManager
import org.json.JSONArray
import org.json.JSONObject

/** Vision tools shared by both flavors. */
object VisionTools {
    val NAMES = setOf("vision", "switch_camera", "take_photo_now", "describe_last_frame")

    fun declarations(): List<JSONObject> = listOf(
        functionDecl("vision", "Start, stop or check the live camera so you can SEE what the user shows. Use when the user says things like 'dekho', 'look at this', 'camera on karo'.",
            mapOf("action" to "start, stop or status", "camera" to "back or front (optional)"), listOf("action")),
        functionDecl("switch_camera", "Switch between the front and back camera while vision is on."),
        functionDecl("take_photo_now", "Save a photo from the live camera to the gallery."),
        functionDecl("describe_last_frame", "Look again at the most recent camera frame and describe it.")
    )

    fun instruction(): String =
        "Vision: you can see through the phone camera ONLY while vision is on. Use the vision tool (action start/stop/status) when the user asks you to look. " +
            "Never claim to see anything when vision is off."

    fun execute(ctx: Context, name: String, args: JSONObject): JSONObject {
        val app = ctx.applicationContext
        return when (name) {
            "vision" -> when (args.optString("action").lowercase()) {
                "start" -> {
                    if (ContextCompat.checkSelfPermission(app, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        ToolResults.status("needs_permission", "Ask the user to open Vision and allow the camera")
                    } else {
                        VisionController.requestOpen()
                        try {
                            app.startActivity(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                        } catch (ignored: Exception) {}
                        ToolResults.status("starting")
                    }
                }
                "stop" -> { VisionController.stop(); ToolResults.status("stopped") }
                else -> JSONObject().put("status", if (VisionController.state.value.active) "active" else "off")
            }
            "switch_camera" -> if (!VisionController.state.value.active) ToolResults.status("vision_not_active")
            else ToolResults.status("ask_user", "Tap the switch button on the Vision screen")
            "take_photo_now" -> if (!VisionController.state.value.active) ToolResults.status("vision_not_active")
            else ToolResults.status("ask_user", "Tap the Photo button on the Vision screen")
            "describe_last_frame" -> {
                val f = VisionController.lastFrameJpeg()
                if (f == null) ToolResults.status("no_frame")
                else { VoiceSessionManager.sendVideoFrame(f); ToolResults.status("frame_sent") }
            }
            else -> ToolResults.unknown(name)
        }
    }
}
