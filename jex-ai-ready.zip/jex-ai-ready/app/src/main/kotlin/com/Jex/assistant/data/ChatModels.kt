package com.Jex.assistant.data

import org.json.JSONArray
import org.json.JSONObject

data class ChatMessage(
    val id: Long,
    val text: String,
    val isUser: Boolean,
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val forgeChip: Boolean = false
)

data class Conversation(
    val id: Long,
    val title: String,
    val messages: List<ChatMessage>,
    val updatedAt: Long
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("updatedAt", updatedAt)
        put("messages", JSONArray().also { arr ->
            messages.forEach { m ->
                arr.put(JSONObject().apply {
                    put("id", m.id); put("text", m.text); put("user", m.isUser); put("error", m.isError)
                })
            }
        })
    }

    companion object {
        fun fromJson(o: JSONObject): Conversation {
            val arr = o.optJSONArray("messages") ?: JSONArray()
            val msgs = (0 until arr.length()).map { i ->
                val m = arr.getJSONObject(i)
                ChatMessage(m.optLong("id"), m.optString("text"), m.optBoolean("user"), false, m.optBoolean("error"))
            }
            return Conversation(o.optLong("id"), o.optString("title", "Chat"), msgs, o.optLong("updatedAt"))
        }

        fun listFromJson(json: String): List<Conversation> = try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }
        } catch (ignored: Exception) {
            emptyList()
        }

        fun listToJson(list: List<Conversation>): String =
            JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }.toString()
    }
}
