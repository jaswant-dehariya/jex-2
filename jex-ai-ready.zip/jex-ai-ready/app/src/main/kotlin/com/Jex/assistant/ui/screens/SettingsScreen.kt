package com.Jex.assistant.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.R
import com.Jex.assistant.data.ApiKeyStore
import com.Jex.assistant.data.AssistantBrand
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.data.LanguagePreference
import com.Jex.assistant.data.ThemeMode
import com.Jex.assistant.ui.components.JexChoiceDialog
import com.Jex.assistant.ui.components.JexGlassCard
import com.Jex.assistant.ui.components.JexSectionHeader
import com.Jex.assistant.ui.components.JexSettingsRow
import com.Jex.assistant.ui.components.JexTextInputDialog
import com.Jex.assistant.ui.nav.Routes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.depthSurface

val VOICE_NAMES = listOf("Aoede", "Puck", "Charon", "Kore", "Fenrir", "Leda", "Orus", "Zephyr")

@Composable
fun SettingsScreen(appState: JexAppState, nav: NavHostController) {
    val ctx = LocalContext.current
    val c = LocalJexColors.current
    var dialog by remember { mutableStateOf<String?>(null) }
    var keySaved by remember { mutableStateOf(ApiKeyStore.hasKey(ctx)) }

    JexScreenColumn("Settings", onBack = null) {
        // Profile card with the avatar over a soft glow
        JexGlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), onClick = { nav.navigate(Routes.PROFILE) }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(CircleShape).depthSurface(c, CircleShape, 8.dp), contentAlignment = Alignment.Center) {
                    Image(painterResource(R.drawable.jex_logo), null, Modifier.size(44.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(appState.userName.ifBlank { AssistantBrand.FULL_NAME }, style = JexType.title.copy(color = c.textPrimary))
                    Text(AssistantBrand.CREDIT_LINE, style = JexType.caption.copy(color = c.textSecondary))
                }
            }
        }

        JexSectionHeader("Gemini")
        SectionCard {
            JexSettingsRow(
                Icons.Filled.Key, "Gemini API key", subtitle = "Stored only on this device",
                value = if (keySaved) "Saved" else "Not set", onClick = { dialog = "key" }
            )
        }

        JexSectionHeader("Assistant")
        SectionCard {
            JexSettingsRow(Icons.Filled.Face, "Assistant name", value = appState.assistantName, onClick = { dialog = "name" })
            JexSettingsRow(Icons.Filled.Person, "Personality", value = appState.personality.displayName, onClick = { nav.navigate(Routes.PERSONALITY) })
            JexSettingsRow(Icons.Filled.Language, "Language", value = appState.language.displayName, onClick = { dialog = "language" })
            JexSettingsRow(Icons.Filled.RecordVoiceOver, "Voice", value = appState.voiceName, onClick = { dialog = "voice" })
        }

        JexSectionHeader("Voice")
        SectionCard {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Icon(Icons.Filled.VolumeUp, null, tint = c.accent)
                    Spacer(Modifier.width(12.dp))
                    Text("Voice volume", style = JexType.title.copy(color = c.textPrimary))
                }
                Slider(
                    value = appState.voiceVolume, onValueChange = { appState.applyVoiceVolume(it) }, valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent)
                )
            }
        }

        JexSectionHeader("Appearance")
        SectionCard {
            JexSettingsRow(Icons.Filled.DarkMode, "Theme", value = appState.themeMode.displayName, onClick = { dialog = "theme" })
            JexSettingsRow(Icons.Filled.Palette, "Orb style", value = appState.orbStyle.displayName, onClick = { nav.navigate(Routes.ORB_STYLE) })
            JexSettingsRow(
                Icons.Filled.Animation, "Reduced motion", subtitle = "Calmer animations",
                switchValue = appState.reducedMotion, onSwitch = { appState.applyReducedMotion(it) }
            )
        }

        FlavorSettingsRows(appState, nav)

        JexSectionHeader("More")
        SectionCard {
            JexSettingsRow(Icons.Filled.Security, "Permissions", onClick = { nav.navigate(Routes.PERMISSIONS) })
            JexSettingsRow(Icons.Filled.Lock, "Privacy", onClick = { nav.navigate(Routes.PRIVACY) })
            JexSettingsRow(Icons.Filled.Info, "About", onClick = { nav.navigate(Routes.ABOUT) })
            JexSettingsRow(Icons.Filled.BugReport, "Voice pipeline debugger", onClick = { nav.navigate(Routes.DEBUG) })
        }
    }

    when (dialog) {
        "key" -> JexTextInputDialog("Gemini API key", "", "Paste your key", secret = true, onConfirm = {
            if (it.isNotBlank()) { ApiKeyStore.saveKey(ctx, it); keySaved = true }
        }, onDismiss = { dialog = null })
        "name" -> JexTextInputDialog("Assistant name", appState.assistantName, "Name", onConfirm = { appState.applyAssistantName(it) }, onDismiss = { dialog = null })
        "language" -> JexChoiceDialog("Language", LanguagePreference.entries.toList(), { it.displayName + " · " + it.description },
            appState.language, { appState.applyLanguage(it) }, { dialog = null })
        "voice" -> JexChoiceDialog("Voice", VOICE_NAMES, { it }, appState.voiceName, { appState.applyVoiceName(it) }, { dialog = null })
        "theme" -> JexChoiceDialog("Theme", ThemeMode.entries.toList(), { it.displayName }, appState.themeMode, { appState.applyThemeMode(it) }, { dialog = null })
    }
}

@Composable
fun SectionCard(content: @Composable () -> Unit) {
    JexGlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
        Column { content() }
    }
}
