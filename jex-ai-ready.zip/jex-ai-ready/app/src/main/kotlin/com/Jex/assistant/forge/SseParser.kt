package com.Jex.assistant.forge

import org.json.JSONObject

/** Parses Gemini streamGenerateContent?alt=sse "data:" lines. */
object SseParser {
    private fun payload(line: String): String? {
        val t = line.trim()
        if (!t.startsWith("data:")) return null
        val p = t.removePrefix("data:").trim()
        if (p.isEmpty() || p == "[DONE]") return null
        return p
    }

    fun extractText(line: String): String? {
        val p = payload(line) ?: return null
        return try {
            val parts = JSONObject(p).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought")) continue
                sb.append(part.optString("text"))
            }
            sb.toString().takeIf { it.isNotEmpty() }
        } catch (ignored: Exception) {
            null
        }
    }

    fun extractError(line: String): String? {
        val p = payload(line) ?: return null
        return try {
            val e = JSONObject(p).optJSONObject("error") ?: return null
            val status = e.optString("status")
            val msg = e.optString("message")
            listOf(status, msg).filter { it.isNotBlank() }.joinToString(": ").ifBlank { "error" }
        } catch (ignored: Exception) {
            null
        }
    }

    fun extractFinishReason(line: String): String? {
        val p = payload(line) ?: return null
        return try {
            JSONObject(p).optJSONArray("candidates")?.optJSONObject(0)?.optString("finishReason")?.takeIf { it.isNotBlank() }
        } catch (ignored: Exception) {
            null
        }
    }
}
