package com.Jex.assistant.forge

import java.io.File

enum class ForgePhase { IDLE, BUILDING, DONE, FAILED, CANCELLED }

data class ForgeMetrics(
    val chars: Int = 0,
    val sections: Int = 0,
    val elapsedSec: Int = 0,
    val tokensPerSec: Int = 0
)

data class ForgeUiState(
    val phase: ForgePhase = ForgePhase.IDLE,
    val prompt: String = "",
    val isEdit: Boolean = false,
    val stage: ForgeStage = ForgeStage.READING,
    val progress: Float = 0f,
    val metrics: ForgeMetrics = ForgeMetrics(),
    val sections: List<String> = emptyList(),
    val log: List<String> = emptyList(),
    val logSeq: Int = 0,
    val buildId: Long = 0L,
    val file: File? = null,
    val error: String? = null
)

sealed class ForgeStartResult(val message: String) {
    object Started : ForgeStartResult("Opening the Forge now.")
    object MissingKey : ForgeStartResult("Add your Gemini API key in Settings first.")
    object Offline : ForgeStartResult("You're offline. Connect to the internet to build a website.")
    object Busy : ForgeStartResult("A website is already being built. Wait for it or cancel it first.")
    object NothingToEdit : ForgeStartResult("There's no website to edit yet. Build one first.")
}
