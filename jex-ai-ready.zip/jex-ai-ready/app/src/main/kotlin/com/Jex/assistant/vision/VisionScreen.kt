package com.Jex.assistant.vision

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavHostController
import android.widget.Toast
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.ui.components.JexButton
import com.Jex.assistant.ui.components.JexButtonStyle
import com.Jex.assistant.ui.components.JexSettingsRow
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import kotlinx.coroutines.launch

@Composable
fun VisionScreen(appState: JexAppState, nav: NavHostController) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val c = LocalJexColors.current
    val scope = rememberCoroutineScope()
    val vstate by VisionController.state.collectAsState()
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val previewView = remember { PreviewView(ctx).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE } }

    LaunchedEffect(granted) {
        if (!granted) launcher.launch(Manifest.permission.CAMERA)
        else VisionController.bind(ctx, owner, previewView)
    }
    DisposableEffect(Unit) {
        onDispose {
            if (appState.keepVisionBackground && VisionController.state.value.active) {
                VisionService.start(ctx)
            } else {
                VisionController.stop()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (granted) AndroidView({ previewView }, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (vstate.active) "Jex can see this" else "Starting camera...", style = JexType.label.copy(color = c.textPrimary))
                JexButton("Close", { nav.popBackStack() }, style = JexButtonStyle.SECONDARY, icon = Icons.Filled.Close)
            }
            Column {
                if (!granted) JexButton("Allow camera", { launcher.launch(Manifest.permission.CAMERA) })
                vstate.error?.let { Text(it, style = JexType.body.copy(color = c.error)) }
                JexSettingsRow(
                    Icons.Filled.CameraAlt, "Keep vision on in background", subtitle = "Uses a visible notification",
                    switchValue = appState.keepVisionBackground, onSwitch = { appState.applyKeepVisionBackground(it) }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    JexButton("Switch", { VisionController.switchCamera(ctx, owner, previewView) }, Modifier.weight(1f), JexButtonStyle.SECONDARY, Icons.Filled.Cameraswitch)
                    JexButton("Photo", {
                        scope.launch {
                            val uri = VisionController.takePhoto(ctx)
                            Toast.makeText(ctx, if (uri != null) "Photo saved to Pictures/Jex" else "Couldn't save the photo", Toast.LENGTH_SHORT).show()
                        }
                    }, Modifier.weight(1f), JexButtonStyle.PRIMARY, Icons.Filled.CameraAlt)
                }
            }
        }
    }
}
