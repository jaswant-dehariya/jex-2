package com.Jex.assistant.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.R
import com.Jex.assistant.data.AssistantBrand
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.license.AccessKeySection
import com.Jex.assistant.ui.components.JexSectionHeader
import com.Jex.assistant.ui.components.JexSettingsRow
import com.Jex.assistant.ui.components.JexTextInputDialog
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors

@Composable
fun ProfileScreen(appState: JexAppState, nav: NavHostController) {
    val c = LocalJexColors.current
    var dialog by remember { mutableStateOf<String?>(null) }
    JexScreenColumn("Profile", onBack = { nav.popBackStack() }) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.jex_logo), "Jex AI", Modifier.size(96.dp))
            Text(AssistantBrand.FULL_NAME, style = JexType.headline.copy(color = c.textPrimary), modifier = Modifier.padding(top = 8.dp))
            Text(AssistantBrand.TAGLINE, style = JexType.voice.copy(color = c.textSecondary), textAlign = TextAlign.Center)
        }
        JexSectionHeader("You")
        SectionCard {
            JexSettingsRow(Icons.Filled.Person, "Your name", value = appState.userName.ifBlank { "Not set" }, onClick = { dialog = "user" })
            JexSettingsRow(Icons.Filled.Face, "Assistant name", value = appState.assistantName, onClick = { dialog = "assistant" })
        }
        AccessKeySection()
        JexSectionHeader("Credit")
        SectionCard {
            JexSettingsRow(Icons.Filled.Favorite, AssistantBrand.CREDIT_LINE, onClick = { dialog = "credit" })
        }
        Spacer(Modifier.height(8.dp))
    }
    when (dialog) {
        "user" -> JexTextInputDialog("Your name", appState.userName, "Name", { appState.applyUserName(it) }, { dialog = null })
        "assistant" -> JexTextInputDialog("Assistant name", appState.assistantName, "Name", { appState.applyAssistantName(it) }, { dialog = null })
        "credit" -> AlertDialog(
            onDismissRequest = { dialog = null }, containerColor = c.surfaceRaised,
            title = { Text(AssistantBrand.FULL_NAME, style = JexType.title.copy(color = c.textPrimary)) },
            text = { Text(AssistantBrand.CREDIT_LINE, style = JexType.headline.copy(color = c.accent)) },
            confirmButton = { TextButton({ dialog = null }) { Text("Close", color = c.accent) } }
        )
    }
}
