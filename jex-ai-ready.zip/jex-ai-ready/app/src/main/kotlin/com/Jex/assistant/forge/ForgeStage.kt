package com.Jex.assistant.forge

enum class ForgeStage(val label: String) {
    READING("Reading your idea"),
    STRUCTURE("Laying out structure"),
    STYLING("Styling sections"),
    VISUALS("Building 3D visuals"),
    MOTION("Injecting motion"),
    FINALIZING("Finalizing"),
    READY("Ready");

    /** Index 0..6 used for progress. */
    val index: Int get() = ordinal
}

object ForgeStageDetector {
    private val photoRegex = Regex("picsum\\.photos|i\\.pravatar\\.cc|pravatar\\.cc|images\\.unsplash\\.com", RegexOption.IGNORE_CASE)
    private val blockRegex = Regex("<(header|section|footer)\\b", RegexOption.IGNORE_CASE)

    fun detect(partialHtml: String): ForgeStage {
        if (partialHtml.isBlank()) return ForgeStage.READING
        if (partialHtml.contains("</html>", ignoreCase = true)) return ForgeStage.FINALIZING
        val bodyIdx = partialHtml.indexOf("<body", ignoreCase = true)
        val sectionIdx = partialHtml.indexOf("<section", ignoreCase = true)
        if (bodyIdx < 0 && sectionIdx < 0) return ForgeStage.READING
        val start = if (bodyIdx >= 0) bodyIdx else sectionIdx
        val body = partialHtml.substring(start)
        var stage = ForgeStage.STRUCTURE
        if (blockRegex.findAll(body).count() >= 2) stage = ForgeStage.STYLING
        if (photoRegex.containsMatchIn(body) || body.contains("<canvas", ignoreCase = true) || body.contains("perspective(", ignoreCase = true)) {
            if (stage.ordinal >= ForgeStage.STYLING.ordinal || blockRegex.containsMatchIn(body)) stage = ForgeStage.VISUALS
        }
        if (body.contains("gsap.", ignoreCase = true) || body.contains("ScrollTrigger", ignoreCase = true)) stage = ForgeStage.MOTION
        return stage
    }

    /** max(stage/6, chars/60000), capped at 98 % until done; never goes backwards (caller keeps the max). */
    fun progress(stage: ForgeStage, chars: Int): Float {
        val byStage = minOf(stage.ordinal, 6) / 6f
        val byChars = chars / 60_000f
        return minOf(maxOf(byStage, byChars), 0.98f)
    }
}

object ForgeSections {
    private val sectionTag = Regex("<section\\b([^>]*)>", RegexOption.IGNORE_CASE)
    private val idAttr = Regex("id\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
    private val heading = Regex("<h[1-3][^>]*>(.*?)</h[1-3]>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
    private val tags = Regex("<[^>]+>")

    fun prettify(raw: String): String {
        val cleaned = raw.replace(Regex("[-_]+"), " ").trim()
        return cleaned.split(" ").filter { it.isNotEmpty() }
            .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
    }

    /** Names of sections seen so far, in order. */
    fun extract(partialHtml: String): List<String> {
        val out = ArrayList<String>()
        for ((n, m) in sectionTag.findAll(partialHtml).withIndex()) {
            val attrs = m.groupValues[1]
            val id = idAttr.find(attrs)?.groupValues?.get(1)
            val name = when {
                !id.isNullOrBlank() -> prettify(id)
                else -> {
                    val after = partialHtml.substring(m.range.last + 1, minOf(partialHtml.length, m.range.last + 1 + 800))
                    val h = heading.find(after)?.groupValues?.get(1)?.replace(tags, "")?.trim().orEmpty()
                    if (h.isNotEmpty()) h.take(24) else "Section ${n + 1}"
                }
            }
            out.add(name)
        }
        return out
    }
}
