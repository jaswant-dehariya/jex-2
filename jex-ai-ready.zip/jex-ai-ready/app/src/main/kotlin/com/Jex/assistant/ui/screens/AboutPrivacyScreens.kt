package com.Jex.assistant.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.BuildConfig
import com.Jex.assistant.data.AssistantBrand
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.ui.components.JexGlassCard
import com.Jex.assistant.ui.fx.JexOrb3D
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.voice.JexOrbState

@Composable
fun AboutScreen(appState: JexAppState, nav: NavHostController) {
    val c = LocalJexColors.current
    JexScreenColumn("About", onBack = { nav.popBackStack() }) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            JexOrb3D(JexOrbState.IDLE, 120.dp, 0.05f, style = appState.orbStyle)
            Text(AssistantBrand.FULL_NAME, style = JexType.display.copy(color = c.textPrimary), modifier = Modifier.padding(top = 12.dp))
            Text(AssistantBrand.TAGLINE, style = JexType.voice.copy(color = c.textSecondary), textAlign = TextAlign.Center)
            Text(AssistantBrand.CREDIT_LINE, style = JexType.title.copy(color = c.accent), modifier = Modifier.padding(top = 16.dp))
            Text(
                "Version ${BuildConfig.VERSION_NAME} · " + if (BuildConfig.DIRECT) "direct build" else "Play build",
                style = JexType.caption.copy(color = c.textTertiary), modifier = Modifier.padding(top = 8.dp)
            )
        }
        SectionCard {
            Text(
                "${AssistantBrand.FULL_NAME} is a voice-first AI companion. Talk in Hindi, Hinglish or English, open apps, call or message people, " +
                    "chat by text, and ask it to build a full animated website while you watch it happen in 3D.",
                style = JexType.body.copy(color = c.textSecondary), modifier = Modifier.padding(16.dp)
            )
        }
    }
}

@Composable
fun PrivacyScreen(nav: NavHostController) {
    val c = LocalJexColors.current
    val points = listOf(
        "Your Gemini API key is typed by you and stored only on this phone. It is never written to logs.",
        "Voice audio is streamed to Google's Gemini Live service only while a voice session is running.",
        "Typed chats and website requests are sent to Gemini to get an answer. Conversation history stays on this device.",
        "Generated websites are saved inside the app's private storage and run in a sandboxed viewer.",
        "Jex AI never sends a message silently in the Play build: it only opens the composer and you tap Send.",
        "Notifications, screen content and camera frames (direct build, when you turn those features on) are held in memory only and never written to disk."
    )
    JexScreenColumn("Privacy", onBack = { nav.popBackStack() }) {
        SectionCard {
            Column(Modifier.padding(16.dp)) {
                points.forEach {
                    Text("• $it", style = JexType.body.copy(color = c.textSecondary), modifier = Modifier.padding(bottom = 10.dp))
                }
            }
        }
    }
}
