package com.Jex.assistant.ui.screens.forge

import android.annotation.SuppressLint
import android.graphics.Color as AColor
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.Jex.assistant.forge.ForgeStage
import com.Jex.assistant.forge.ForgeUiState
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.sin

/** The 3D workshop. Falls back to [ForgeFallbackScene] when Three.js or WebGL is unavailable. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ForgeWebGlScene(state: ForgeUiState, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var fallback by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    val webView = remember {
        WebView(ctx).apply {
            setBackgroundColor(AColor.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            val loader = WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                .build()
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)
            }
            addJavascriptInterface(
                ForgeJsBridge({ post { ready = true } }, { post { fallback = true } }), "ForgeJsBridge"
            )
            loadUrl("https://appassets.androidplatform.net/assets/forge/forge.html")
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            webView.removeJavascriptInterface("ForgeJsBridge")
            webView.destroy()
        }
    }
    LaunchedEffect(state.stage, state.progress, state.sections, state.phase, ready) {
        if (!ready) return@LaunchedEffect
        val json = JSONObject()
            .put("stage", state.stage.index)
            .put("progress", state.progress.toDouble())
            .put("phase", state.phase.name)
            .put("sections", JSONArray(state.sections))
        webView.evaluateJavascript("window.forge && window.forge.setState(${json})", null)
    }
    if (fallback) {
        ForgeFallbackScene(state, modifier)
    } else {
        AndroidView({ webView }, modifier)
    }
}

/** Pure Compose scene: rotating core + orbiting section chips, used when WebGL is not available. */
@Composable
fun ForgeFallbackScene(state: ForgeUiState, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "forgeFallback")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart), label = "a")
    val colors = listOf(0xFF8B5CF6, 0xFF3FE0D0, 0xFFFF6FAE, 0xFFFFB547, 0xFFFF8A3D, 0xFFFFE2B0, 0xFF3FE0D0)
    val tint = Color(colors[state.stage.index.coerceIn(0, 6)])
    Canvas(modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = size.minDimension * 0.17f
        drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = 0.5f), Color.Transparent), c, r * 3.2f), r * 3.2f, c)
        drawCircle(Brush.radialGradient(listOf(Color.White, tint, tint.copy(alpha = 0.6f)), c - Offset(r * 0.3f, r * 0.3f), r * 1.4f), r, c)
        drawCircle(Color.White.copy(alpha = 0.25f), r * 2.1f, c, style = Stroke(3f))
        val sweep = 360f * state.progress.coerceIn(0.02f, 1f)
        drawArc(Color(0xFFFFB547), -90f, sweep, false, Offset(c.x - r * 2.8f, c.y - r * 2.8f), androidx.compose.ui.geometry.Size(r * 5.6f, r * 5.6f), style = Stroke(6f))
        val n = state.sections.size
        for (i in 0 until n) {
            val a = Math.toRadians((angle + i * 360.0 / n))
            val p = Offset(c.x + cos(a).toFloat() * r * 3.6f, c.y + sin(a).toFloat() * r * 1.6f)
            drawRoundRect(Color(colors[i % colors.size]).copy(alpha = 0.9f), p - Offset(34f, 20f), androidx.compose.ui.geometry.Size(68f, 40f), androidx.compose.ui.geometry.CornerRadius(8f))
        }
    }
}
