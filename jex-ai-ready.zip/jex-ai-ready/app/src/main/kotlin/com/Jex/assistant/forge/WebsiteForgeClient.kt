package com.Jex.assistant.forge

import android.util.Log
import com.Jex.assistant.voice.GeminiTextClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

data class StreamResult(
    val finishReason: String? = null,
    val error: String? = null,
    val httpCode: Int = 200
) {
    val overloaded: Boolean
        get() = httpCode == 503 || (error?.contains("UNAVAILABLE", true) == true) ||
            (error?.contains("overloaded", true) == true) || (error?.contains("high demand", true) == true)
}

/** Streams streamGenerateContent?alt=sse. Never logs keys, prompts or HTML. */
object WebsiteForgeClient {
    private const val TAG = "WebsiteForge"
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private val http: OkHttpClient = GeminiTextClient.client.newBuilder()
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    fun resolveModel(apiKey: String): String? = GeminiTextClient.resolveModel(apiKey)

    suspend fun stream(
        apiKey: String,
        model: String,
        systemPrompt: String,
        userPrompt: String,
        onDelta: (String) -> Unit
    ): StreamResult = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put(
                "contents", JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
                )
            )
        val gen = JSONObject().put("temperature", 0.9)
        if (model.contains("2.5")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        payload.put("generationConfig", gen)

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            .header("x-goog-api-key", apiKey)
            .post(payload.toString().toRequestBody(JSON))
            .build()

        val call = http.newCall(req)
        val handle = coroutineContext.job.invokeOnCompletion { if (it != null) call.cancel() }
        try {
            call.execute().use { resp ->
                if (!resp.isSuccessful) {
                    val raw = try { resp.body?.string().orEmpty() } catch (ignored: Exception) { "" }
                    val msg = try { JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty() } catch (ignored: Exception) { "" }
                    Log.w(TAG, "HTTP ${resp.code}")
                    return@withContext StreamResult(error = msg.ifBlank { "HTTP ${resp.code}" }, httpCode = resp.code)
                }
                val source = resp.body?.source() ?: return@withContext StreamResult(error = "empty response")
                var finish: String? = null
                while (true) {
                    coroutineContext.ensureActive()
                    val line = source.readUtf8Line() ?: break
                    SseParser.extractError(line)?.let { return@withContext StreamResult(finish, it, 200) }
                    SseParser.extractText(line)?.let(onDelta)
                    SseParser.extractFinishReason(line)?.let { finish = it }
                }
                if (finish != null && finish != "STOP") Log.w(TAG, "finishReason=$finish")
                StreamResult(finishReason = finish)
            }
        } catch (e: IOException) {
            coroutineContext.ensureActive()
            StreamResult(error = "Couldn't reach Gemini. Check your internet.", httpCode = 0)
        } finally {
            handle.dispose()
        }
    }

    fun friendlyError(r: StreamResult): String = when {
        r.overloaded -> "Gemini is busy right now. Please try again in a minute."
        r.httpCode in listOf(400, 401, 403) -> "Gemini rejected the request. Check your API key in Settings."
        r.httpCode == 429 -> "Gemini is rate-limiting you. Wait a little and try again."
        r.httpCode == 0 -> "Couldn't reach Gemini. Check your internet."
        else -> "Gemini couldn't build the website (${r.error?.take(80) ?: "unknown"})."
    }
}
