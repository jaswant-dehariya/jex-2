package com.Jex.assistant.action

import com.Jex.assistant.vision.VisionTools
import org.json.JSONObject

/** Tools and prompt text shared by both flavors. */
object CommonTools {
    fun declarations(): List<JSONObject> = listOf(
        functionDecl(
            "build_website",
            "Build a complete animated 3D website. Use when the user asks to build, create or make a website or landing page. Starts the Forge and returns immediately.",
            mapOf("prompt" to "What the website is about, in the user's words"), listOf("prompt")
        )
    ) + VisionTools.declarations()

    fun instructions(): String =
        "Website builder: when the user asks you to build a website, call build_website with their idea. It starts the Forge screen right away; " +
            "tell the user briefly that the build has started and they can watch it. Never say the site is finished until the Forge screen shows it.\n" +
            VisionTools.instruction()
}
