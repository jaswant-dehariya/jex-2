package com.Jex.assistant.ui.screens.forge

import android.webkit.JavascriptInterface

/** The ONLY object exposed to the Forge scene WebView. Exactly three methods, no data access. */
class ForgeJsBridge(
    private val onReadyCb: () -> Unit,
    private val onFallbackCb: () -> Unit,
    private val onLogCb: (String) -> Unit = {}
) {
    @JavascriptInterface fun onReady() = onReadyCb()
    @JavascriptInterface fun onFallback() = onFallbackCb()
    @JavascriptInterface fun onLog(message: String) = onLogCb(message.take(200))
}
