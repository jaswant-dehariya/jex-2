package com.Jex.assistant.data

import android.content.Context
import org.json.JSONObject

/** Small in-app contact book (name -> number), used by contact_save / contact_delete. */
object ContactStore {
    private fun load(ctx: Context): JSONObject = try {
        JSONObject(JexPreferences.getString(ctx, JexPreferences.Keys.CONTACT_STORE_JSON, "{}"))
    } catch (ignored: Exception) { JSONObject() }

    fun save(ctx: Context, name: String, number: String) {
        val o = load(ctx); o.put(name.trim().lowercase(), number.trim())
        JexPreferences.putString(ctx, JexPreferences.Keys.CONTACT_STORE_JSON, o.toString())
    }

    fun delete(ctx: Context, name: String): Boolean {
        val o = load(ctx); val had = o.has(name.trim().lowercase()); o.remove(name.trim().lowercase())
        JexPreferences.putString(ctx, JexPreferences.Keys.CONTACT_STORE_JSON, o.toString()); return had
    }

    fun find(ctx: Context, name: String): String? {
        val o = load(ctx); val q = name.trim().lowercase()
        if (o.has(q)) return o.optString(q)
        val key = o.keys().asSequence().firstOrNull { it.startsWith(q) || it.contains(q) } ?: return null
        return o.optString(key)
    }

    fun all(ctx: Context): Map<String, String> { val o = load(ctx); return o.keys().asSequence().associateWith { o.optString(it) } }
}
