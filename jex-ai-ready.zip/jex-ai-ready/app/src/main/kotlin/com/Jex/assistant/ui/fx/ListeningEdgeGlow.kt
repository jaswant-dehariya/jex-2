package com.Jex.assistant.ui.fx

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.Jex.assistant.ui.theme.LocalJexReducedMotion
import com.Jex.assistant.voice.JexOrbState

object EdgeGlowColors {
    val Resting = Color(0xFF8B5CF6)
    val Speaking = Color(0xFFFF6FAE)
    val Error = Color(0xFFFF7A85)
    val ScreenShare = Color(0xFF3FE0D0)

    fun forState(state: JexOrbState): Color = when (state) {
        JexOrbState.SPEAKING -> Speaking
        JexOrbState.ERROR -> Error
        else -> Resting
    }
}

/** Slim ~26 dp border glow. Draws only; the host decides where it lives (Dialog or overlay window). */
@Composable
fun ListeningEdgeGlow(state: JexOrbState, modifier: Modifier = Modifier, colorOverride: Color? = null) {
    val reduced = LocalJexReducedMotion.current
    val target = colorOverride ?: EdgeGlowColors.forState(state)
    val color by animateColorAsState(target, tween(400), label = "edge")
    val t = rememberInfiniteTransition(label = "edgePulse")
    val pulse by t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "p")
    val alpha = if (reduced) 0.8f else pulse
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val e = 26.dp.toPx()
        val c0 = color.copy(alpha = 0.85f * alpha)
        val c1 = Color.Transparent
        drawRect(Brush.verticalGradient(listOf(c0, c1), 0f, e), Offset.Zero, Size(w, e))
        drawRect(Brush.verticalGradient(listOf(c1, c0), h - e, h), Offset(0f, h - e), Size(w, e))
        drawRect(Brush.horizontalGradient(listOf(c0, c1), 0f, e), Offset.Zero, Size(e, h))
        drawRect(Brush.horizontalGradient(listOf(c1, c0), w - e, w), Offset(w - e, 0f), Size(e, h))
    }
}
