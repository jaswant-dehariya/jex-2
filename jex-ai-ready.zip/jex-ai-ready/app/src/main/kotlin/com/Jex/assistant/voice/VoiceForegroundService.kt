package com.Jex.assistant.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.Jex.assistant.MainActivity
import com.Jex.assistant.R
import com.Jex.assistant.data.AssistantBrand
import com.Jex.assistant.data.JexPreferences
import com.Jex.assistant.ui.fx.OverlayEdgeGlowController

class VoiceForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            VoiceSessionManager.stop()
            OverlayEdgeGlowController.stop(this)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        val notification = buildNotification(this)
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (ignored: Exception) {
            // Microphone permission missing: do not crash, just stop.
            stopSelf()
            return START_NOT_STICKY
        }
        OverlayEdgeGlowController.start(this)
        VoiceSessionManager.start(this)
        return START_STICKY
    }

    override fun onDestroy() {
        OverlayEdgeGlowController.stop(this)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.Jex.assistant.action.STOP_VOICE"
        const val CHANNEL_ID = "jex_voice_session"
        const val NOTIFICATION_ID = 4101

        private fun assistantName(ctx: Context) =
            JexPreferences.getString(ctx, JexPreferences.Keys.ASSISTANT_NAME, AssistantBrand.NAME).ifBlank { AssistantBrand.NAME }

        fun buildNotification(ctx: Context): Notification {
            val name = assistantName(ctx)
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "$name voice session", NotificationManager.IMPORTANCE_LOW)
                )
            }
            val stop = PendingIntent.getService(
                ctx, 1,
                Intent(ctx, VoiceForegroundService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val open = PendingIntent.getActivity(
                ctx, 2, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_jex)
                .setContentTitle("$name is listening")
                .setContentText("Tap to open, or Stop to end the session")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(0, "Stop", stop)
                .build()
        }

        fun start(ctx: Context) {
            val i = Intent(ctx, VoiceForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, VoiceForegroundService::class.java).setAction(ACTION_STOP))
        }
    }
}
