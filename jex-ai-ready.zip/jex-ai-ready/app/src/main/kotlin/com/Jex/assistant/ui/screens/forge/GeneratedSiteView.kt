package com.Jex.assistant.ui.screens.forge

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import java.io.File

private const val HOST = "appassets.androidplatform.net"

/**
 * Runs a generated page in a locked-down WebView. NOT wrapped in graphicsLayer or any animated container
 * (that would turn the WebGL canvases black). The page is served from the private Websites folder.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GeneratedSiteView(file: File, buildId: Long, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val webView = remember(buildId, file.path) {
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.mediaPlaybackRequiresUserGesture = true
            settings.setSupportMultipleWindows(false)
            val loader = WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/sites/", WebViewAssetLoader.InternalStoragePathHandler(ctx, File(ctx.filesDir, "Websites")))
                .build()
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    // in-page anchors and the site's own file stay inside the view; real external links go to the browser
                    if (uri.host == HOST) return false
                    if (request.isForMainFrame && request.hasGesture()) {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ignored: Exception) {}
                    }
                    return true
                }
            }
            loadUrl("https://$HOST/sites/${Uri.encode(file.name)}")
        }
    }
    DisposableEffect(webView) { onDispose { webView.destroy() } }
    AndroidView({ webView }, modifier)
}
