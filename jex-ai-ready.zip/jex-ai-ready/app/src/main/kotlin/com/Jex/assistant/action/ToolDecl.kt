package com.Jex.assistant.action

import org.json.JSONArray
import org.json.JSONObject

/** Builds a Gemini function declaration. All params are type STRING, parameters type OBJECT. */
fun functionDecl(
    name: String,
    description: String,
    params: Map<String, String> = emptyMap(),
    required: List<String> = emptyList()
): JSONObject {
    val decl = JSONObject().put("name", name).put("description", description)
    if (params.isNotEmpty()) {
        val props = JSONObject()
        params.forEach { (k, v) -> props.put(k, JSONObject().put("type", "STRING").put("description", v)) }
        val schema = JSONObject().put("type", "OBJECT").put("properties", props)
        if (required.isNotEmpty()) schema.put("required", JSONArray(required))
        decl.put("parameters", schema)
    }
    return decl
}

object ToolResults {
    fun status(status: String, reason: String? = null): JSONObject =
        JSONObject().put("status", status).also { if (reason != null) it.put("reason", reason) }

    fun error(msg: String): JSONObject = JSONObject().put("status", "failed").put("error", msg)

    fun unknown(name: String): JSONObject = JSONObject().put("error", "Unknown tool: $name")
}
