package com.Jex.assistant.ui.fx

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import com.Jex.assistant.ui.theme.LocalJexReducedMotion
import com.Jex.assistant.voice.JexOrbState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Canvas orb: fallback for API < 33 and the home of the 7 personality styles. */
@Composable
fun JexCanvasOrb(
    state: JexOrbState,
    style: JexOrbStyle,
    size: Dp,
    amplitude: Float,
    modifier: Modifier = Modifier
) {
    val reduced = LocalJexReducedMotion.current
    val t = rememberInfiniteTransition(label = "orb")
    val breathe by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart), label = "b")
    val rotMs = when (state) { JexOrbState.THINKING -> 2600; JexOrbState.CONNECTING -> 1100; else -> 9000 }
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(rotMs, easing = LinearEasing), RepeatMode.Restart), label = "r")
    val ring by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "ring")
    val (core, rim, halo) = animatedOrbColors(state, style)
    val desc = "Jex status: ${state.name.lowercase()}"

    Canvas(modifier.size(size).semantics { contentDescription = desc }) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val base = this.size.minDimension / 2f * 0.62f
        val breath = if (reduced) 1f else 1f + 0.035f * sin(breathe)
        val amp = amplitude.coerceIn(0f, 1f)
        val r = base * breath * (1f + (if (state == JexOrbState.SPEAKING) amp * 0.18f else 0f))
        val center = Offset(cx, cy)
        val rotation = if (reduced) 0f else rot

        if (style == JexOrbStyle.ARCHER) {
            drawArcherSphere(center, r * 1.25f, rotation, amp, rim.value, core.value, reduced)
            return@Canvas
        }

        // radial outer glow
        drawCircle(Brush.radialGradient(listOf(halo.value.copy(alpha = 0.45f), Color.Transparent), center, r * 1.9f), r * 1.9f, center)

        // expanding rings while listening
        if (state == JexOrbState.LISTENING && !reduced) {
            for (k in 0 until 2) {
                val p = (ring + k * 0.5f) % 1f
                drawCircle(rim.value.copy(alpha = (1f - p) * 0.5f), r * (1.1f + p * 0.7f), center, style = Stroke(2f))
            }
        }
        // rotating arc while connecting
        if (state == JexOrbState.CONNECTING) {
            drawArc(rim.value, rotation, 100f, false, Offset(cx - r * 1.2f, cy - r * 1.2f), Size(r * 2.4f, r * 2.4f), style = Stroke(5f, cap = StrokeCap.Round))
        }
        // orbiting particles
        val particles = when {
            style == JexOrbStyle.MINIMAL || state == JexOrbState.ERROR -> 0
            style == JexOrbStyle.ENERGY -> 8
            style == JexOrbStyle.PLASMA -> 6
            style == JexOrbStyle.GLASS -> 3
            else -> 5
        }
        for (i in 0 until particles) {
            val a = Math.toRadians((rotation + i * 360.0 / particles))
            val pr = r * (1.35f + 0.1f * sin(i * 1.7f))
            drawCircle(rim.value.copy(alpha = 0.8f), 3.5f + (i % 3), Offset(cx + cos(a).toFloat() * pr, cy + sin(a).toFloat() * pr))
        }
        // core
        val coreColor = if (style == JexOrbStyle.MINIMAL) core.value else core.value
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.9f), coreColor, coreColor.copy(alpha = 0.75f), rim.value.copy(alpha = 0.6f)),
                Offset(cx - r * 0.3f, cy - r * 0.3f), r * 1.3f
            ), r, center
        )
        if (style == JexOrbStyle.GLASS) {
            drawArc(Color.White.copy(alpha = 0.85f), 200f, 70f, false, Offset(cx - r * 0.8f, cy - r * 0.8f), Size(r * 1.6f, r * 1.6f), style = Stroke(6f, cap = StrokeCap.Round))
        }
        if (state == JexOrbState.ERROR) {
            val p = (ring)
            drawCircle(rim.value.copy(alpha = (1f - p) * 0.7f), r * (1f + p * 0.5f), center, style = Stroke(3f))
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawArcherSphere(
    center: Offset, radius: Float, rotationDeg: Float, amp: Float, color: Color, glow: Color, reduced: Boolean
) {
    drawCircle(Brush.radialGradient(listOf(glow.copy(alpha = 0.25f), Color.Transparent), center, radius * 1.6f), radius * 1.6f, center)
    val n = 400
    val golden = PI * (3.0 - sqrt(5.0))
    val rot = Math.toRadians(rotationDeg.toDouble())
    for (i in 0 until n) {
        val y = 1.0 - (i / (n - 1.0)) * 2.0
        val rr = sqrt(1.0 - y * y)
        val theta = golden * i + rot
        val x = cos(theta) * rr
        val z = sin(theta) * rr
        val depth = ((z + 1.0) / 2.0).toFloat()
        val jitter = if (reduced) 0f else amp * 0.12f * sin(i * 3.1f + rotationDeg * 0.05f)
        val px = center.x + (x.toFloat() * (1f + jitter)) * radius
        val py = center.y + (y.toFloat() * (1f + jitter)) * radius
        drawCircle(color.copy(alpha = 0.15f + depth * 0.8f), 1.2f + depth * 2.4f, Offset(px, py))
    }
}
