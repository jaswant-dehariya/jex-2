package com.Jex.assistant.voice

enum class DetectedLanguage { HINDI, HINGLISH, ENGLISH, UNKNOWN }

object LanguageDetector {
    private val HINGLISH_MARKERS = setOf(
        "hai", "hain", "ho", "kya", "kyun", "kyu", "kaise", "kaisa", "kaisi", "nahi", "nahin", "haan", "han",
        "mujhe", "tumhe", "tumhara", "aap", "mera", "meri", "mere", "tera", "teri", "yaar", "bhai",
        "accha", "achha", "acha", "theek", "thik", "matlab", "karna", "karo", "kar", "raha", "rahi", "rahe",
        "chahiye", "batao", "bata", "suno", "dekho", "abhi", "phir", "lekin", "bahut", "thoda", "kuch",
        "sab", "wala", "wali", "wale", "kholo", "banao", "bolo", "hum", "tum", "toh", "bhi", "ka", "ki", "ke",
        "ko", "se", "mein", "me", "par", "aur", "kal", "aaj", "ab", "kaun", "kahan", "kab", "kitna", "kitne"
    ).minus(setOf("me", "ka", "ki", "ke", "ko", "se", "par", "kar", "ho", "ab", "han")) // too common in English

    fun detect(text: String): DetectedLanguage {
        if (text.isBlank()) return DetectedLanguage.UNKNOWN
        if (text.any { it.code in 0x0900..0x097F }) return DetectedLanguage.HINDI
        val words = text.lowercase().split(Regex("[^a-zA-Z']+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return DetectedLanguage.UNKNOWN
        val hits = words.count { it in HINGLISH_MARKERS }
        return if (words.size <= 4) {
            if (hits >= 1) DetectedLanguage.HINGLISH else DetectedLanguage.ENGLISH
        } else {
            val ratio = hits.toDouble() / words.size
            if (hits >= 2 || ratio >= 0.15) DetectedLanguage.HINGLISH else DetectedLanguage.ENGLISH
        }
    }
}
