package com.Jex.assistant.ui.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Text
import com.Jex.assistant.data.AssistantBrand
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.LocalJexReducedMotion
import kotlin.math.cos
import kotlin.math.sin

/** Once-per-process intro flag: never replays on rotation or resume. */
object SplashSession {
    @Volatile var played = false
}

/**
 * Stars streak past, the orb condenses from particles, the name appears, then the intro dissolves. <= 2.2 s, skippable.
 */
@Composable
fun JexSplash3D(onFinished: () -> Unit) {
    val c = LocalJexColors.current
    val reduced = LocalJexReducedMotion.current
    val progress = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        if (!reduced) progress.animateTo(1f, tween(1700, easing = LinearEasing)) else progress.snapTo(1f)
        fade.animateTo(0f, tween(if (reduced) 120 else 400))
        finish(onFinished)
    }

    Box(
        Modifier.fillMaxSize().alpha(fade.value).background(c.background)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finish(onFinished) }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val p = progress.value
            drawRect(Brush.verticalGradient(listOf(c.backgroundGradientTop, c.background)))
            // stars streak from the centre
            for (i in 0 until 90) {
                val ang = i * 2.399963f
                val speed = 0.4f + (i % 7) * 0.12f
                val d0 = ((p * speed * 1.6f + (i % 13) / 13f) % 1f)
                val r0 = d0 * size.maxDimension * 0.7f
                val r1 = r0 + 18f + d0 * 60f * (1f - p * 0.6f)
                val a = (1f - d0) * 0.7f * (1f - p * 0.8f)
                drawLine(
                    Color.White.copy(alpha = a.coerceIn(0f, 1f)),
                    Offset(cx + cos(ang) * r0, cy + sin(ang) * r0),
                    Offset(cx + cos(ang) * r1, cy + sin(ang) * r1), 2f
                )
            }
            // particles condense into an orb
            val orbR = 70.dp.toPx() * (0.2f + 0.8f * p.coerceIn(0f, 1f))
            for (i in 0 until 160) {
                val ang = i * 2.399963f
                val far = size.maxDimension * 0.5f * (1f - p) + orbR * (0.3f + (i % 9) / 12f)
                drawCircle(c.accent.copy(alpha = 0.25f + 0.5f * p), 2.5f, Offset(cx + cos(ang) * far, cy + sin(ang) * far))
            }
            drawCircle(Brush.radialGradient(listOf(Color.White, c.accent, c.lotus.copy(alpha = 0.8f)), Offset(cx - orbR * 0.3f, cy - orbR * 0.3f), orbR * 1.4f), orbR, Offset(cx, cy))
        }
        Column(
            Modifier.align(Alignment.Center).padding(top = 230.dp).alpha(((progress.value - 0.5f) * 2f).coerceIn(0f, 1f)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(AssistantBrand.FULL_NAME, style = JexType.display.copy(color = c.textPrimary))
            Text(AssistantBrand.CREDIT_LINE, style = JexType.voice.copy(color = c.textSecondary))
        }
    }
}

private var finished = false
private fun finish(cb: () -> Unit) {
    if (finished) return
    finished = true
    SplashSession.played = true
    cb()
}
