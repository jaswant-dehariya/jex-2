package com.Jex.assistant.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import kotlin.math.sqrt

/** Mic capture (16 kHz) and low-latency speaker playback (24 kHz). No logging in the audio path. */
class LiveAudioIO(
    private val onMicChunk: (ByteArray) -> Unit,
    private val onMicAmplitude: (Float) -> Unit
) {
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile private var recording = false
    private var thread: Thread? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null
    @Volatile private var volume = 1f

    @SuppressLint("MissingPermission")
    fun startMic(): Boolean {
        if (recording) return true
        val minBuf = AudioRecord.getMinBufferSize(MIC_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufSize = maxOf(minBuf, 4096)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, MIC_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize
            )
        } catch (ignored: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        val sid = rec.audioSessionId
        try { if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(sid)?.also { it.enabled = true } } catch (ignored: Exception) {}
        try { if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(sid)?.also { it.enabled = true } } catch (ignored: Exception) {}
        try { if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(sid)?.also { it.enabled = true } } catch (ignored: Exception) {}
        record = rec
        recording = true
        try {
            rec.startRecording()
        } catch (ignored: Exception) {
            recording = false
            rec.release()
            record = null
            return false
        }
        thread = Thread({
            val buf = ByteArray(CHUNK_BYTES)
            while (recording) {
                val n = try { rec.read(buf, 0, buf.size) } catch (ignored: Exception) { -1 }
                if (n <= 0) {
                    if (n < 0) break else continue
                }
                val chunk = if (n == buf.size) buf.copyOf() else buf.copyOf(n)
                onMicAmplitude(rms(chunk, n))
                onMicChunk(chunk)
            }
        }, "jex-mic").also { it.isDaemon = true; it.start() }
        return true
    }

    fun stopMic() {
        recording = false
        try { thread?.join(300) } catch (ignored: Exception) {}
        thread = null
        try { record?.stop() } catch (ignored: Exception) {}
        try { aec?.release() } catch (ignored: Exception) {}
        try { ns?.release() } catch (ignored: Exception) {}
        try { agc?.release() } catch (ignored: Exception) {}
        aec = null; ns = null; agc = null
        try { record?.release() } catch (ignored: Exception) {}
        record = null
    }

    private fun ensureTrack(): AudioTrack {
        track?.let { return it }
        val minBuf = AudioTrack.getMinBufferSize(SPEAKER_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SPEAKER_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(minBuf * 4)
            .build()
        t.setVolume(volume)
        t.play()
        track = t
        return t
    }

    /** Plays a chunk and returns that chunk's RMS (0..1). */
    fun playChunk(bytes: ByteArray): Float {
        val t = try { ensureTrack() } catch (ignored: Exception) { return 0f }
        try { t.write(bytes, 0, bytes.size) } catch (ignored: Exception) {}
        return rms(bytes, bytes.size)
    }

    fun flushPlayback() {
        val t = track ?: return
        try {
            t.pause()
            t.flush()
            t.play()
        } catch (ignored: Exception) {}
    }

    fun setVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        try { track?.setVolume(volume) } catch (ignored: Exception) {}
    }

    fun release() {
        stopMic()
        try { track?.stop() } catch (ignored: Exception) {}
        try { track?.release() } catch (ignored: Exception) {}
        track = null
    }

    companion object {
        const val MIC_RATE = 16000
        const val SPEAKER_RATE = 24000
        const val CHUNK_BYTES = 2048

        /** Little-endian PCM16 RMS in 0..1. */
        fun rms(pcm: ByteArray, length: Int = pcm.size): Float {
            val samples = length / 2
            if (samples == 0) return 0f
            var sum = 0.0
            var i = 0
            while (i + 1 < length) {
                val s = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toInt()
                sum += s.toDouble() * s.toDouble()
                i += 2
            }
            val v = sqrt(sum / samples) / 32768.0
            return v.toFloat().coerceIn(0f, 1f)
        }
    }
}
