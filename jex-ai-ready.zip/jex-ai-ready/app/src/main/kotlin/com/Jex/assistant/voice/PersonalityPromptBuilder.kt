package com.Jex.assistant.voice

import com.Jex.assistant.data.LanguagePreference
import com.Jex.assistant.data.Personality
import com.Jex.assistant.action.JexCapabilityPrompts

object PersonalityPromptBuilder {

    fun languagePolicy(language: LanguagePreference, detected: DetectedLanguage): String = when (language) {
        LanguagePreference.AUTO -> buildString {
            append("Language policy: match the user's language turn by turn (Hindi, Hinglish or English) and never translate what they said.")
            if (detected != DetectedLanguage.UNKNOWN) {
                append(" The user most recently spoke ${detected.name.lowercase()}.")
            }
        }
        LanguagePreference.HINDI -> "Language policy: always answer in Hindi (Devanagari script), even if the user speaks another language."
        LanguagePreference.HINGLISH -> "Language policy: always answer in Hinglish (Hindi written in English letters), even if the user speaks another language."
        LanguagePreference.ENGLISH -> "Language policy: always answer in English, even if the user speaks another language."
    }

    const val SAFETY =
        "Safety: never claim to be human. No sexually explicit content. Stop a topic when the user asks you to. " +
            "Vary your phrasing so you never sound scripted."

    fun build(
        personality: Personality,
        language: LanguagePreference,
        detectedLanguage: DetectedLanguage,
        recap: String?,
        assistantName: String
    ): String {
        val parts = mutableListOf<String>()
        parts += "You are $assistantName, a persistent personal voice assistant living on the user's phone. " +
            "Keep replies short and conversational, like spoken conversation.\n" + IdentityPrompt.build()
        parts += JexCapabilityPrompts.toolInstruction(assistantName)
        parts += personality.systemInstruction
        parts += languagePolicy(language, detectedLanguage)
        parts += SAFETY
        if (recap != null) {
            parts += "This is a continuing conversation — do not greet again. Recap:\n$recap"
        }
        return parts.joinToString("\n\n")
    }
}
