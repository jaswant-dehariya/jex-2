package com.Jex.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.forge.ForgeController
import com.Jex.assistant.ui.components.JexGlassCard
import com.Jex.assistant.ui.components.JexTopBar
import com.Jex.assistant.ui.nav.Routes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalBottomBarInset
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.voice.VoiceForegroundService
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.PaddingValues
import android.widget.Toast

@Composable
fun QuickActionsScreen(appState: JexAppState, nav: NavHostController) {
    val c = LocalJexColors.current
    val ctx = LocalContext.current
    val inset = LocalBottomBarInset.current
    val tiles = buildList {
        add(QuickTile("Open an app", "YouTube kholo", Icons.Filled.Apps) { cx, n ->
            VoiceForegroundService.start(cx); n.navigate(Routes.VOICE)
        })
        add(QuickTile("Call", "Mummy ko call karo", Icons.Filled.Call) { cx, n ->
            VoiceForegroundService.start(cx); n.navigate(Routes.VOICE)
        })
        add(QuickTile("Message", "Rahul ko WhatsApp karo", Icons.Filled.Chat) { cx, n ->
            VoiceForegroundService.start(cx); n.navigate(Routes.VOICE)
        })
        add(QuickTile("Build a website", "Ek cafe ki website banao", Icons.Filled.Language) { cx, n ->
            n.navigate(Routes.CHAT)
            Toast.makeText(cx, "Type what website you want, e.g. \"build a cafe website\"", Toast.LENGTH_LONG).show()
        })
        add(QuickTile("My websites", "Saved websites", Icons.Filled.Language) { _, n -> n.navigate(Routes.FORGE) })
        addAll(flavorQuickTiles())
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        JexTopBar("Quick actions", onBack = { nav.popBackStack() })
        LazyVerticalGrid(
            GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = inset.calculateBottomPadding() + 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(tiles) { t ->
                JexGlassCard(Modifier.fillMaxWidth(), onClick = { t.onClick(ctx, nav) }) {
                    Column(Modifier.padding(16.dp)) {
                        Box(Modifier.size(44.dp).background(c.accentGlow, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(t.icon, null, tint = c.accent)
                        }
                        Text(t.title, style = JexType.title.copy(color = c.textPrimary), modifier = Modifier.padding(top = 10.dp))
                        Text("\u201C${t.phrase}\u201D", style = JexType.caption.copy(color = c.textSecondary))
                    }
                }
            }
        }
    }
}
