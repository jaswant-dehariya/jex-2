package com.Jex.assistant.ui.nav

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val CHAT = "chat"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val VOICE = "voice"
    const val QUICK_ACTIONS = "quick_actions"
    const val PROFILE = "profile"
    const val PERSONALITY = "personality"
    const val ORB_STYLE = "orb_style"
    const val PRIVACY = "privacy"
    const val PERMISSIONS = "permissions"
    const val ABOUT = "about"
    const val DEBUG = "debug"
    const val FORGE = "forge"
    const val VISION = "vision"
    const val ACCESSIBILITY_DISCLOSURE = "accessibility_disclosure"

    val BAR_ROUTES = setOf(HOME, CHAT, HISTORY, SETTINGS)
}
