package com.Jex.assistant.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.data.ApiKeyStore
import com.Jex.assistant.data.ChatMessage
import com.Jex.assistant.data.Conversation
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.forge.ForgeController
import com.Jex.assistant.forge.ForgeIntent
import com.Jex.assistant.forge.ForgeStartResult
import com.Jex.assistant.ui.components.JexButton
import com.Jex.assistant.ui.components.JexButtonStyle
import com.Jex.assistant.ui.components.JexMessageBubble
import com.Jex.assistant.ui.fx.JexOrb3D
import com.Jex.assistant.ui.nav.Routes
import com.Jex.assistant.ui.theme.JexShapes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalBottomBarInset
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.MinTouchTarget
import com.Jex.assistant.ui.theme.depthSurface
import com.Jex.assistant.voice.ChatPromptBuilder
import com.Jex.assistant.voice.ChatReplyResult
import com.Jex.assistant.voice.ChatTurn
import com.Jex.assistant.voice.GeminiTextClient
import com.Jex.assistant.voice.JexOrbState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** History sets this; Chat consumes it to open an old conversation. */
object ChatSession {
    @Volatile var pendingConversationId: Long? = null
}

@Composable
fun ChatScreen(appState: JexAppState, nav: NavHostController) {
    val ctx = LocalContext.current
    val c = LocalJexColors.current
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var input by remember { mutableStateOf("") }
    var typing by remember { mutableStateOf(false) }
    var conversationId by remember { mutableStateOf(System.currentTimeMillis()) }
    var idCounter by remember { mutableStateOf(System.currentTimeMillis() + 1) }
    val listState = rememberLazyListState()
    val inset = LocalBottomBarInset.current

    // Text-to-speech created once, shut down on dispose.
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        val engine = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
        }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    LaunchedEffect(Unit) {
        ChatSession.pendingConversationId?.let { id ->
            appState.conversations.firstOrNull { it.id == id }?.let {
                conversationId = it.id
                messages.clear(); messages.addAll(it.messages)
            }
            ChatSession.pendingConversationId = null
        }
    }
    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    fun nextId(): Long = idCounter++

    fun persist() {
        val real = messages.filter { !it.isStreaming }
        val first = real.firstOrNull { it.isUser }?.text ?: return
        appState.saveConversation(Conversation(conversationId, first.take(40), real.toList(), System.currentTimeMillis()))
    }

    fun requestReply() {
        val placeholderId = nextId()
        messages.add(ChatMessage(placeholderId, "", false, isStreaming = true))
        typing = true
        scope.launch {
            val history = messages.filter { !it.isStreaming && !it.isError && !it.forgeChip }.map { ChatTurn(it.isUser, it.text) }
            val system = ChatPromptBuilder.build(appState.personality, appState.language, appState.assistantName)
            val result = withContext(Dispatchers.IO) { GeminiTextClient.reply(ApiKeyStore.getKey(ctx), system, history) }
            val idx = messages.indexOfFirst { it.id == placeholderId }
            if (idx < 0) { typing = false; return@launch }
            when (result) {
                is ChatReplyResult.Success -> {
                    // word-by-word reveal, 20 ms per word
                    val words = result.text.split(" ")
                    val sb = StringBuilder()
                    for (w in words) {
                        if (sb.isNotEmpty()) sb.append(' ')
                        sb.append(w)
                        val i = messages.indexOfFirst { it.id == placeholderId }
                        if (i >= 0) messages[i] = ChatMessage(placeholderId, sb.toString(), false, isStreaming = true)
                        delay(20)
                    }
                    val i = messages.indexOfFirst { it.id == placeholderId }
                    if (i >= 0) messages[i] = ChatMessage(placeholderId, result.text, false)
                }
                is ChatReplyResult.Error -> messages[idx] = ChatMessage(placeholderId, result.message, false, isError = true)
            }
            typing = false
            persist()
        }
    }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || typing) return
        input = ""
        messages.add(ChatMessage(nextId(), text, true))
        val forgePrompt = ForgeIntent.extract(text)
        if (forgePrompt != null) {
            val r = ForgeController.start(ctx, forgePrompt)
            val reply = if (r is ForgeStartResult.Started) "Opening the Forge now. Watch your website being built in 3D." else r.message
            messages.add(ChatMessage(nextId(), reply, false, forgeChip = r is ForgeStartResult.Started))
            persist()
            return
        }
        persist()
        requestReply()
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }, Modifier.size(MinTouchTarget)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = c.textPrimary)
            }
            JexOrb3D(if (typing) JexOrbState.THINKING else JexOrbState.IDLE, 40.dp, 0f, style = appState.orbStyle)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(appState.assistantName, style = JexType.title.copy(color = c.textPrimary))
                Text(if (typing) "Typing..." else "Here to help", style = JexType.caption.copy(color = c.textSecondary))
            }
        }
        if (messages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Ask me anything. I answer in your language.", style = JexType.voice.copy(color = c.textSecondary), modifier = Modifier.padding(32.dp))
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
                items(messages, key = { it.id }) { m ->
                    JexMessageBubble(m, actions = {
                        if (m.forgeChip) {
                            JexButton("Open Forge", { nav.navigate(Routes.FORGE) }, style = JexButtonStyle.SECONDARY)
                        } else {
                            IconButton(onClick = {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("Jex", m.text))
                            }, Modifier.size(MinTouchTarget)) { Icon(Icons.Filled.ContentCopy, "Copy", tint = c.textTertiary) }
                            IconButton(onClick = { tts?.speak(m.text, TextToSpeech.QUEUE_FLUSH, null, "jex-${m.id}") }, Modifier.size(MinTouchTarget)) {
                                Icon(Icons.Filled.VolumeUp, "Speak", tint = c.textTertiary)
                            }
                            if (m.isError) {
                                IconButton(onClick = {
                                    messages.removeAll { it.id == m.id }
                                    requestReply()
                                }, Modifier.size(MinTouchTarget)) { Icon(Icons.Filled.Refresh, "Retry", tint = c.textTertiary) }
                            }
                        }
                    })
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = inset.calculateBottomPadding().coerceAtLeast(10.dp))
                .depthSurface(c, JexShapes.pill, 8.dp, c.surfaceRaised).padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f).padding(vertical = 10.dp)) {
                if (input.isEmpty()) Text("Message ${appState.assistantName}", style = JexType.body.copy(color = c.textTertiary))
                BasicTextField(
                    value = input, onValueChange = { input = it },
                    textStyle = JexType.body.copy(color = c.textPrimary), cursorBrush = SolidColor(c.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send() }),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Box(
                Modifier.size(MinTouchTarget).clip(CircleShape).background(c.accent, CircleShape).clickable { send() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = c.onAccent) }
        }
    }
}
