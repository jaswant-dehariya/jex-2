package com.Jex.assistant.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.ui.components.JexTopBar
import com.Jex.assistant.ui.fx.JexCanvasOrb
import com.Jex.assistant.ui.fx.JexOrb3D
import com.Jex.assistant.ui.fx.JexOrbStyle
import com.Jex.assistant.ui.theme.JexShapes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalBottomBarInset
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.MinTouchTarget
import com.Jex.assistant.voice.JexOrbState
import kotlin.math.abs

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OrbStyleScreen(appState: JexAppState, nav: NavHostController) {
    val c = LocalJexColors.current
    val inset = LocalBottomBarInset.current
    var previewState by remember { mutableStateOf(JexOrbState.IDLE) }
    val styles = JexOrbStyle.entries.toList()
    val listState = rememberLazyListState()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        JexTopBar("Orb style", onBack = { nav.popBackStack() })
        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            JexOrb3D(previewState, 240.dp, if (previewState == JexOrbState.SPEAKING) 0.5f else 0.05f, style = appState.orbStyle)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
            listOf(JexOrbState.IDLE to "Idle", JexOrbState.LISTENING to "Listening", JexOrbState.SPEAKING to "Speaking").forEach { (st, label) ->
                val sel = st == previewState
                Text(
                    label, style = JexType.label.copy(color = if (sel) c.onAccent else c.textPrimary),
                    modifier = Modifier.padding(horizontal = 4.dp).heightIn(min = MinTouchTarget).clip(JexShapes.pill)
                        .background(if (sel) c.accent else c.surfaceGlass, JexShapes.pill)
                        .clickable { previewState = st }.padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }
        }
        LazyRow(
            state = listState,
            flingBehavior = rememberSnapFlingBehavior(listState),
            contentPadding = PaddingValues(horizontal = 120.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = inset.calculateBottomPadding() + 16.dp)
        ) {
            itemsIndexed(styles) { _, style ->
                // coverflow: scale up and tilt according to distance from the viewport centre
                val info = listState.layoutInfo
                val item = info.visibleItemsInfo.firstOrNull { it.key == style.name || it.index == styles.indexOf(style) }
                val viewportCenter = (info.viewportStartOffset + info.viewportEndOffset) / 2f
                val dist = if (item != null) ((item.offset + item.size / 2f) - viewportCenter) / (item.size.coerceAtLeast(1)) else 0f
                val selected = style == appState.orbStyle
                Column(
                    Modifier.graphicsLayer {
                        rotationY = (dist * -35f).coerceIn(-35f, 35f)
                        val s = 1f - 0.2f * abs(dist).coerceAtMost(1.5f)
                        scaleX = s; scaleY = s
                        cameraDistance = 16f * density
                    }.clickable { appState.applyOrbStyle(style) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(110.dp).then(if (selected) Modifier.border(2.dp, c.accent, JexShapes.large) else Modifier),
                        contentAlignment = Alignment.Center
                    ) {
                        JexCanvasOrb(JexOrbState.LISTENING, style, 100.dp, 0.2f)
                    }
                    Text(style.displayName, style = JexType.label.copy(color = if (selected) c.accent else c.textSecondary))
                }
            }
        }
    }
}
