package com.Jex.assistant.ui.nav

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.forge.ForgeController
import com.Jex.assistant.ui.screens.AboutScreen
import com.Jex.assistant.ui.screens.ChatScreen
import com.Jex.assistant.ui.screens.DebugScreen
import com.Jex.assistant.ui.screens.HistoryScreen
import com.Jex.assistant.ui.screens.HomeScreen
import com.Jex.assistant.ui.screens.OnboardingScreen
import com.Jex.assistant.ui.screens.OrbStyleScreen
import com.Jex.assistant.ui.screens.PermissionsScreen
import com.Jex.assistant.ui.screens.PersonalityScreen
import com.Jex.assistant.ui.screens.PrivacyScreen
import com.Jex.assistant.ui.screens.ProfileScreen
import com.Jex.assistant.ui.screens.QuickActionsScreen
import com.Jex.assistant.ui.screens.SettingsScreen
import com.Jex.assistant.ui.screens.VoiceScreen
import com.Jex.assistant.ui.screens.forge.ForgeScreen
import com.Jex.assistant.ui.screens.registerAccessibilityDisclosureRoute
import com.Jex.assistant.ui.theme.LocalJexColors
import com.Jex.assistant.ui.theme.LocalBottomBarInset
import com.Jex.assistant.ui.theme.nightSky
import com.Jex.assistant.ui.theme.rememberTilt
import com.Jex.assistant.vision.VisionScreen

@Composable
fun JexApp(appState: JexAppState) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = route in Routes.BAR_ROUTES
    val c = LocalJexColors.current
    val (tx, ty) = rememberTilt(!appState.reducedMotion)
    val pendingOpen by ForgeController.pendingOpen.collectAsState()

    LaunchedEffect(pendingOpen) {
        if (pendingOpen) {
            ForgeController.consumePendingOpen()
            nav.navigate(Routes.FORGE) { launchSingleTop = true }
        }
    }

    val visionPending by com.Jex.assistant.vision.VisionController.pendingOpen.collectAsState()
    LaunchedEffect(visionPending) {
        if (visionPending) {
            com.Jex.assistant.vision.VisionController.consumePendingOpen()
            nav.navigate(Routes.VISION) { launchSingleTop = true }
        }
    }

    fun go(r: String) {
        if (r == route) return
        nav.navigate(r) {
            if (r in Routes.BAR_ROUTES) {
                popUpTo(Routes.HOME) { saveState = true }
                restoreState = true
            }
            launchSingleTop = true
        }
    }

    CompositionLocalProvider(LocalBottomBarInset provides PaddingValues(bottom = if (showBar) 104.dp else 0.dp)) {
        Box(Modifier.fillMaxSize().nightSky(c, tx, ty)) {
            NavHost(
                navController = nav,
                startDestination = if (appState.hasOnboarded) Routes.HOME else Routes.ONBOARDING,
                modifier = Modifier.fillMaxSize(),
                enterTransition = { EnterTransition.None },
                exitTransition = { ExitTransition.None },
                popEnterTransition = { EnterTransition.None },
                popExitTransition = { ExitTransition.None }
            ) {
                composable(Routes.SPLASH) { HomeScreen(appState, nav) }
                composable(Routes.ONBOARDING) {
                    OnboardingScreen(appState) {
                        appState.applyHasOnboarded(true)
                        nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                    }
                }
                composable(Routes.HOME) { HomeScreen(appState, nav) }
                composable(Routes.CHAT) { ChatScreen(appState, nav) }
                composable(Routes.HISTORY) { HistoryScreen(appState, nav) }
                composable(Routes.SETTINGS) { SettingsScreen(appState, nav) }
                composable(Routes.VOICE) { VoiceScreen(appState, nav) }
                composable(Routes.QUICK_ACTIONS) { QuickActionsScreen(appState, nav) }
                composable(Routes.PROFILE) { ProfileScreen(appState, nav) }
                composable(Routes.PERSONALITY) { PersonalityScreen(appState, nav) }
                composable(Routes.ORB_STYLE) { OrbStyleScreen(appState, nav) }
                composable(Routes.PRIVACY) { PrivacyScreen(nav) }
                composable(Routes.PERMISSIONS) { PermissionsScreen(nav) }
                composable(Routes.ABOUT) { AboutScreen(appState, nav) }
                composable(Routes.DEBUG) { DebugScreen(appState, nav) }
                composable(Routes.VISION) { VisionScreen(appState, nav) }
                composable(Routes.FORGE) { ForgeScreen(appState, nav) }
                registerAccessibilityDisclosureRoute(nav)
            }
            if (showBar) {
                JexBottomNavigation(route, ::go, appState.orbStyle, Modifier.align(Alignment.BottomCenter))
            }
        }
    }
}
