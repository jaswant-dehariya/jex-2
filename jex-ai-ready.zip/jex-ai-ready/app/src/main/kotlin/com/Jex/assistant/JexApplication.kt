package com.Jex.assistant

import android.app.Application
import android.content.Context

/** Keeps an application context for process-wide singletons (voice, forge, tasks). */
class JexApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContextHolder.init(this)
    }
}

object AppContextHolder {
    @Volatile private var app: Context? = null

    fun init(context: Context) {
        app = context.applicationContext
    }

    /** Never null once JexApplication.onCreate ran. */
    fun get(): Context = checkNotNull(app) { "JexApplication not created yet" }

    fun getOrNull(): Context? = app
}
