package com.Jex.assistant

import com.Jex.assistant.action.QuickSettingsTiles
import com.Jex.assistant.action.ScreenDriver
import com.Jex.assistant.action.SystemToggles
import com.Jex.assistant.agent.core.Blocker
import com.Jex.assistant.agent.core.ScreenObservation
import com.Jex.assistant.agent.core.TargetResolver
import com.Jex.assistant.agent.core.UiElement
import com.Jex.assistant.agent.layers.ConfirmationPolicy
import com.Jex.assistant.agent.layers.PlanStep
import com.Jex.assistant.agent.layers.Planner
import com.Jex.assistant.agent.layers.Risk
import com.Jex.assistant.agent.layers.StepExecutor
import com.Jex.assistant.agent.layers.StepVerifier
import com.Jex.assistant.agent.layers.TaskManager
import com.Jex.assistant.agent.layers.TaskRunState
import com.Jex.assistant.agent.social.BlockerDetector
import com.Jex.assistant.agent.social.IllegalTransitionException
import com.Jex.assistant.agent.social.SocialTaskRequest
import com.Jex.assistant.agent.social.TaskState
import com.Jex.assistant.agent.social.TaskStateMachine
import com.Jex.assistant.callagent.CallPolicy
import com.Jex.assistant.callagent.CallState
import com.Jex.assistant.callagent.CallStateMachine
import com.Jex.assistant.callagent.IllegalCallTransition
import com.Jex.assistant.license.AccessKeyRules
import com.Jex.assistant.license.LicenseStatus
import com.Jex.assistant.notify.NotificationEvent
import com.Jex.assistant.notify.NotificationRules
import com.Jex.assistant.share.FormGuideMachine
import com.Jex.assistant.share.FormState
import com.Jex.assistant.share.FrameDiff
import com.Jex.assistant.share.GuideAction
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class TaskStateMachineTest {
    @Test fun happyPath() {
        val m = TaskStateMachine()
        listOf(TaskState.OPENING_APP, TaskState.OBSERVING, TaskState.RESOLVING_TARGET, TaskState.VALIDATING_TARGET, TaskState.EXECUTING_ACTION,
            TaskState.WAITING_FOR_UI, TaskState.VERIFYING, TaskState.COMPLETED).forEach { m.moveTo(it) }
        assertEquals(TaskState.COMPLETED, m.state)
    }
    @Test fun illegalThrows() { try { TaskStateMachine().moveTo(TaskState.VERIFYING); fail() } catch (ignored: IllegalTransitionException) {} }
    @Test fun terminalNeverExits() {
        val m = TaskStateMachine(); m.moveTo(TaskState.FAILED)
        try { m.moveTo(TaskState.OPENING_APP); fail() } catch (ignored: IllegalTransitionException) {}
    }
    @Test fun cancelFromAnywhereNonTerminal() { val m = TaskStateMachine(); m.moveTo(TaskState.OPENING_APP); m.moveTo(TaskState.CANCELLED); assertTrue(m.state.isTerminal) }
    @Test fun confirmationOnlyLeadsToExecute() {
        assertTrue(TaskStateMachine.canMove(TaskState.WAITING_FOR_CONFIRMATION, TaskState.EXECUTING_ACTION))
        assertFalse(TaskStateMachine.canMove(TaskState.WAITING_FOR_CONFIRMATION, TaskState.COMPLETED))
    }
}

class SocialRequestTest {
    @Test fun needsMediaForPost() {
        val r = SocialTaskRequest.parse(JSONObject().put("platform", "instagram").put("action", "create_post"))
        assertTrue(r is SocialTaskRequest.Parsed.Invalid)
    }
    @Test fun rejectsNonContentUri() {
        val r = SocialTaskRequest.parse(JSONObject().put("platform", "instagram").put("action", "create_post").put("media_uri", "file:///sdcard/x.jpg"))
        assertTrue(r is SocialTaskRequest.Parsed.Invalid)
    }
    @Test fun acceptsSharedContentUri() {
        val r = SocialTaskRequest.parse(JSONObject().put("platform", "facebook").put("action", "create_post").put("media_uri", "content://x/y").put("caption", "hi"))
        assertTrue(r is SocialTaskRequest.Parsed.Ok)
    }
    @Test fun textPostNeedsCaption() = assertTrue(SocialTaskRequest.parse(JSONObject().put("platform", "facebook").put("action", "text_post")) is SocialTaskRequest.Parsed.Invalid)
}

class TargetAndBlockerTest {
    private fun obs(vararg e: UiElement) = ScreenObservation(1, "pkg", e.toList(), 0)
    @Test fun resolverPrefersExactButton() {
        val o = obs(UiElement("Share to story", "text"), UiElement("Share", "button"))
        assertEquals("Share", TargetResolver.resolve(o, "share")!!.label)
    }
    @Test fun blockerCaptcha() = assertEquals(Blocker.CAPTCHA, BlockerDetector.detect(obs(UiElement("Please solve the CAPTCHA", "text"))))
    @Test fun blockerLogin() = assertEquals(Blocker.LOGIN, BlockerDetector.detect(obs(UiElement("Log in", "button"), UiElement("Password", "input"))))
    @Test fun noBlocker() = assertNull(BlockerDetector.detect(obs(UiElement("Next", "button"))))
}

class FormGuideTest {
    @Test fun walksFieldsInOrder() {
        val m = FormGuideMachine()
        val a = m.advance(listOf("[input] Name (empty)", "[input] Mobile number (empty)"))
        assertEquals(GuideAction.Announce("Name"), a)
        assertEquals(GuideAction.Wait, m.advance(listOf("[input] Name (empty)", "[input] Mobile number (empty)")))
        val f = m.advance(listOf("[input] Name (filled: Rahul)", "[input] Mobile number (empty)"))
        assertEquals(GuideAction.Filled("Name", "Mobile number"), f)
        assertEquals(FormState.FIELD_ANNOUNCED, m.state)
    }
    @Test fun doneWhenAllFilled() {
        val m = FormGuideMachine()
        m.advance(listOf("[input] Name (empty)"))
        m.advance(listOf("[input] Name (filled: A)"))
        assertEquals(GuideAction.AllDone, m.advance(listOf("[input] Name (filled: A)")))
    }
    @Test fun pauseWaits() { val m = FormGuideMachine(); m.pause(); assertEquals(GuideAction.Wait, m.advance(listOf("[input] A (empty)"))) }
}

class FrameDiffTest {
    @Test fun identicalIsZero() = assertEquals(0f, FrameDiff.difference(IntArray(256) { 10 }, IntArray(256) { 10 }), 0f)
    @Test fun skipsSmallChange() = assertFalse(FrameDiff.shouldSend(0.005f, 5000, 4500, 100))
    @Test fun sendsAfterMaxGap() = assertTrue(FrameDiff.shouldSend(0f, 8000, 4000, 100))
    @Test fun detectsBlackWindow() = assertTrue(FrameDiff.isBlack(IntArray(256)))
}

class NotificationRulesTest {
    private fun ev(t: Long, text: String = "hi") = NotificationEvent(1, "k", "com.a", "A", "Bob", text, emptyList(), t, null, false)
    @Test fun skipsOngoingAndOwn() {
        assertTrue(NotificationRules.shouldSkip(true, false, false, null, "x", "me"))
        assertTrue(NotificationRules.shouldSkip(false, false, false, null, "me", "me"))
        assertTrue(NotificationRules.shouldSkip(false, false, false, "transport", "x", "me"))
        assertFalse(NotificationRules.shouldSkip(false, false, false, "msg", "x", "me"))
    }
    @Test fun duplicatesWithinTwoSeconds() { assertTrue(NotificationRules.isDuplicate(ev(0), ev(1500))); assertFalse(NotificationRules.isDuplicate(ev(0), ev(2500))) }
    @Test fun otpIsSensitiveAndMasked() {
        assertTrue(NotificationRules.isSensitive("Your OTP is 482913"))
        assertFalse(NotificationRules.maskSensitive("Your OTP is 482913").contains("482913"))
    }
    @Test fun denyBeatsAllow() { assertFalse(NotificationRules.appAllowed("a", "a", "a")); assertTrue(NotificationRules.appAllowed("a", "", "")) }
}

class CallLogicTest {
    @Test fun premiumBlocked() = assertTrue(CallPolicy.isPremiumRate("+1900123456"))
    @Test fun dailyLimit() = assertNotNull(CallPolicy.mayCall("98765", true, CallPolicy.DAILY_LIMIT))
    @Test fun onlyNamedNumbers() = assertNotNull(CallPolicy.mayCall("98765", false, 0))
    @Test fun okCall() = assertNull(CallPolicy.mayCall("9876543210", true, 0))
    @Test fun promptDisclosesAi() = assertTrue(CallPolicy.systemPrompt("Asha", "book table", listOf("2 people"), "Hindi").contains("Jex AI"))
    @Test fun stateMachine() {
        val m = CallStateMachine()
        listOf(CallState.DIALING, CallState.RINGING, CallState.CONNECTED, CallState.TALKING, CallState.ENDING, CallState.SUMMARY).forEach { m.moveTo(it) }
        assertEquals(CallState.SUMMARY, m.state)
    }
    @Test fun illegalCallTransition() { try { CallStateMachine().moveTo(CallState.TALKING); fail() } catch (ignored: IllegalCallTransition) {} }
}

class MiscDirectTest {
    @Test fun quickTiles() {
        assertEquals("Wi-Fi", QuickSettingsTiles.findTile(listOf("Torch", "Wi-Fi, On"), "wifi")?.substringBefore(","))
        assertTrue(QuickSettingsTiles.looksOn("Bluetooth, On"))
    }
    @Test fun volumePercent() { assertEquals(8, SystemToggles.volumeIndexForPercent(50, 15)); assertEquals(100, SystemToggles.clampPercent(250)) }
    @Test fun licenseRules() {
        assertEquals(LicenseStatus.NOT_CONFIGURED, AccessKeyRules.evaluate(false, true, false, 0, 1))
        assertEquals(LicenseStatus.NO_KEY, AccessKeyRules.evaluate(true, false, false, 0, 1))
        assertEquals(LicenseStatus.BLOCKED, AccessKeyRules.evaluate(true, true, true, 0, 1))
        assertEquals(LicenseStatus.EXPIRED, AccessKeyRules.evaluate(true, true, false, 5, 10))
        assertEquals(LicenseStatus.ACTIVE, AccessKeyRules.evaluate(true, true, false, 0, 10))
    }
    @Test fun verifier() {
        assertTrue(StepVerifier.check(null, emptyList()))
        assertTrue(StepVerifier.check("text:Search", listOf("[button] Search")))
        assertTrue(StepVerifier.check("gone:Loading", listOf("[text] Done")))
        assertFalse(StepVerifier.check("gone:Loading", listOf("[text] Loading...")))
    }
    @Test fun confirmationPolicy() {
        assertEquals(Risk.NEEDS_CONFIRM, ConfirmationPolicy.riskOf("whatsapp_message"))
        assertEquals(Risk.SAFE, ConfirmationPolicy.riskOf("set_flashlight"))
        val step = PlanStep("whatsapp_message", JSONObject(), null, Risk.NEEDS_CONFIRM)
        assertFalse(ConfirmationPolicy.allowed(step, "Rahul ko message", emptySet()))
        assertTrue(ConfirmationPolicy.allowed(step, "Rahul ko message bhej do", emptySet()))
        assertTrue(ConfirmationPolicy.allowed(step, "x", setOf("whatsapp_message")))
    }
    @Test fun plannerParsesJsonAndCaps() {
        val steps = (1..40).joinToString(",") { "{\"tool\":\"go_home\",\"args\":{}}" }
        val parsed = Planner.parse("```json\n{\"steps\":[$steps]}\n```")
        assertEquals(25, parsed.size)
        assertTrue(Planner.parse("garbage").isEmpty())
    }
}

private class FakeDriver : ScreenDriver {
    var lines = listOf("[text] Home")
    override fun isAvailable() = true
    override fun readScreenLines(maxElements: Int, maxLabelLength: Int) = lines
    override fun clickText(text: String) = true
    override fun typeText(text: String) = true
    override fun globalAction(action: Int) = true
    override suspend fun scroll(direction: String) = "scrolled"
    override suspend fun swipe(direction: String) = true
    override suspend fun tapAt(x: Int, y: Int) = true
    override fun actionableLabels() = emptyList<String>()
    override fun currentPackage(): String? = "pkg"
}

class TaskManagerTest {
    private fun mgr(exec: StepExecutor, plan: List<PlanStep>) = TaskManager(
        driverProvider = { FakeDriver() }, executor = exec, planner = { plan }
    )

    @Test fun runsSimplePlanToCompletion() = runBlocking {
        val calls = ArrayList<String>()
        val m = mgr({ s -> calls.add(s.tool); JSONObject().put("status", "done") }, listOf(PlanStep("go_home", JSONObject()), PlanStep("set_flashlight", JSONObject())))
        val id = m.start("torch on karo").getString("task_id")
        var tries = 0
        while (m.get(id)!!.state != TaskRunState.COMPLETED && tries++ < 100) delay(50)
        assertEquals(TaskRunState.COMPLETED, m.get(id)!!.state)
        assertEquals(listOf("go_home", "set_flashlight"), calls)
    }

    @Test fun failingStepFailsTask() = runBlocking {
        val m = mgr({ JSONObject().put("status", "failed") }, listOf(PlanStep("go_home", JSONObject())))
        val id = m.start("x").getString("task_id")
        var tries = 0
        while (m.get(id)!!.state != TaskRunState.FAILED && tries++ < 100) delay(50)
        assertEquals(TaskRunState.FAILED, m.get(id)!!.state)
    }

    @Test fun irreversibleWaitsWithoutImperative() = runBlocking {
        val sent = ArrayList<String>()
        val m = mgr({ s -> sent.add(s.tool); JSONObject().put("status", "done") }, listOf(PlanStep("whatsapp_message", JSONObject(), null, Risk.NEEDS_CONFIRM)))
        val id = m.start("Rahul ko message").getString("task_id")
        var tries = 0
        while (m.get(id)!!.state != TaskRunState.WAITING_FOR_USER && tries++ < 100) delay(50)
        assertEquals(TaskRunState.WAITING_FOR_USER, m.get(id)!!.state)
        assertTrue(sent.isEmpty())
        m.cancel(id)
        assertEquals(TaskRunState.CANCELLED, m.get(id)!!.state)
    }

    @Test fun maxThreeConcurrent() = runBlocking {
        val m = mgr({ delay(2000); JSONObject().put("status", "done") }, listOf(PlanStep("go_home", JSONObject())))
        repeat(3) { m.start("t$it") }
        assertEquals("too_many_tasks", m.start("fourth").getString("status"))
        m.cancelAll()
    }
}
