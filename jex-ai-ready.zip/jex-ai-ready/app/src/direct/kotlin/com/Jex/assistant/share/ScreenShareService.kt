package com.Jex.assistant.share

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.Jex.assistant.R
import com.Jex.assistant.vision.FrameSourceArbiter
import com.Jex.assistant.voice.VoiceSessionManager

/** Foreground service (mediaProjection) with an ongoing "watching your screen" notification and a STOP action. */
class ScreenShareService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val streamer = FrameStreamer()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(userRequested = true); return START_NOT_STICKY }
        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }

        startForegroundNow()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = try { mpm.getMediaProjection(code, data) } catch (ignored: Exception) { null }
        if (mp == null) { stopSelf(); return START_NOT_STICKY }
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // The system revoked the projection: tell the user, out loud and in a notification.
                ScreenShareController.postNotice("Screen share was stopped by the system.")
                VoiceSessionManager.say("[System] Screen sharing was stopped by Android. Tell the user briefly.")
                shutdown(userRequested = false)
            }
        }, Handler(mainLooper))

        val dm = resources.displayMetrics
        val long = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
        val scale = if (long > 1024f) 1024f / long else 1f
        val w = (dm.widthPixels * scale).toInt().coerceAtLeast(2)
        val h = (dm.heightPixels * scale).toInt().coerceAtLeast(2)
        val t = HandlerThread("jex-share").also { it.start() }
        thread = t
        val handler = Handler(t.looper)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (ignored: Exception) { null } ?: return@setOnImageAvailableListener
            try {
                val plane = img.planes[0]
                val rowPadding = plane.rowStride - plane.pixelStride * w
                val bmp = Bitmap.createBitmap(w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(plane.buffer)
                val cropped = if (bmp.width != w) Bitmap.createBitmap(bmp, 0, 0, w, h).also { bmp.recycle() } else bmp
                streamer.onFrame(cropped)
                cropped.recycle()
            } catch (ignored: Exception) {
            } finally { img.close() }
        }, handler)
        display = mp.createVirtualDisplay("jex-share", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)

        FrameSourceArbiter.start(FrameSourceArbiter.Source.SCREEN, keepOther = false)
        ScreenShareController.setActive(true)
        return START_NOT_STICKY
    }

    private fun startForegroundNow() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen share", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 41, Intent(this, ScreenShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_stat_jex)
            .setContentTitle("Jex AI is watching your screen").setContentText("Tap Stop to end sharing")
            .setOngoing(true).addAction(0, "Stop", stop).build()
        if (Build.VERSION.SDK_INT >= 29) ServiceCompat.startForeground(this, 4103, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(4103, n)
    }

    private fun shutdown(userRequested: Boolean) {
        try { display?.release() } catch (ignored: Exception) {}
        try { reader?.close() } catch (ignored: Exception) {}
        try { projection?.stop() } catch (ignored: Exception) {}
        try { thread?.quitSafely() } catch (ignored: Exception) {}
        display = null; reader = null; projection = null; thread = null
        ScreenShareController.setActive(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (ScreenShareController.active.value) shutdown(false)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.Jex.assistant.action.STOP_SHARE"
        private const val CHANNEL = "jex_screen_share"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"

        fun start(ctx: Context, resultCode: Int, data: Intent) {
            val i = Intent(ctx, ScreenShareService::class.java).putExtra(EXTRA_CODE, resultCode).putExtra(EXTRA_DATA, data)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }
}
