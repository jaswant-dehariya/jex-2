package com.Jex.assistant.share

import com.Jex.assistant.action.ScreenDriver
import kotlinx.coroutines.delay

data class FormField(val label: String, val filled: Boolean)

enum class FormState { IDLE, FIELD_ANNOUNCED, WAITING_FOR_INPUT, FIELD_FILLED, DONE, PAUSED }

sealed class GuideAction {
    data class Announce(val field: String) : GuideAction()
    data class Filled(val field: String, val next: String?) : GuideAction()
    object Wait : GuideAction()
    object Scroll : GuideAction()
    object AllDone : GuideAction()
}

/** Pure state machine for guided form mode: FIELD_ANNOUNCED -> WAITING_FOR_INPUT -> FIELD_FILLED -> NEXT. */
class FormGuideMachine {
    var state = FormState.IDLE; private set
    private var currentLabel: String? = null
    private val done = LinkedHashSet<String>()
    private var skipRequested = false

    fun pause() { state = FormState.PAUSED }
    fun resume() { if (state == FormState.PAUSED) state = if (currentLabel != null) FormState.WAITING_FOR_INPUT else FormState.IDLE }
    fun skip() { skipRequested = true }

    companion object {
        /** Parses "[input] Mobile number (empty)" lines into fields; passwords never expose text. */
        fun parseFields(lines: List<String>): List<FormField> = lines.filter { it.startsWith("[input]") }.map { line ->
            val body = line.removePrefix("[input]").trim()
            val filled = !body.endsWith("(empty)")
            val label = body.substringBefore(" (").ifBlank { body }
            FormField(label.trim(), filled)
        }
    }

    fun advance(lines: List<String>): GuideAction {
        if (state == FormState.PAUSED) return GuideAction.Wait
        val fields = parseFields(lines)
        if (fields.isEmpty()) return if (done.isNotEmpty()) { state = FormState.DONE; GuideAction.AllDone } else GuideAction.Scroll
        val cur = currentLabel
        if (cur != null) {
            val f = fields.firstOrNull { it.label == cur }
            if (skipRequested) {
                skipRequested = false; done.add(cur); currentLabel = null
            } else if (f != null && f.filled) {
                done.add(cur); currentLabel = null
                state = FormState.FIELD_FILLED
                val next = fields.firstOrNull { !it.filled && it.label !in done }
                if (next != null) { currentLabel = next.label; state = FormState.FIELD_ANNOUNCED }
                else state = FormState.DONE
                return GuideAction.Filled(cur, next?.label)
            } else {
                state = FormState.WAITING_FOR_INPUT
                return GuideAction.Wait
            }
        }
        val next = fields.firstOrNull { !it.filled && it.label !in done }
        if (next == null) { state = FormState.DONE; return GuideAction.AllDone }
        currentLabel = next.label
        state = FormState.FIELD_ANNOUNCED
        return GuideAction.Announce(next.label)
    }
}
