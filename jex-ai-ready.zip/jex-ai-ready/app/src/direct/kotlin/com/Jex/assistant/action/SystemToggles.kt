package com.Jex.assistant.action

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import kotlinx.coroutines.delay
import org.json.JSONObject

object QuickSettingsTiles {
    private val synonyms = mapOf(
        "wifi" to listOf("wi-fi", "wifi", "internet"),
        "bluetooth" to listOf("bluetooth"),
        "airplane" to listOf("airplane", "aeroplane", "flight")
    )

    /** Finds the tile label for a toggle kind among labels on screen ("Wi-Fi, On" style labels allowed). */
    fun findTile(labels: List<String>, kind: String): String? {
        val keys = synonyms[kind] ?: return null
        return labels.firstOrNull { l -> keys.any { l.lowercase().contains(it) } }
    }

    fun looksOn(label: String): Boolean {
        val l = label.lowercase()
        return l.contains(", on") || l.endsWith(" on") || l.contains("connected")
    }
}

object SystemToggles {
    fun clampPercent(p: Int) = p.coerceIn(0, 100)

    fun volumeIndexForPercent(percent: Int, max: Int): Int = Math.round(clampPercent(percent) / 100f * max)

    private fun result(status: String, reason: String? = null) = ToolResults.status(status, reason)

    fun flashlight(ctx: Context, on: Boolean): JSONObject = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id == null) result("failed", "No flashlight on this phone") else { cm.setTorchMode(id, on); result("done") }
    } catch (e: Exception) { result("failed", "Couldn't switch the flashlight") }

    fun volumeChange(ctx: Context, direction: String): JSONObject {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val dir = if (direction.lowercase().startsWith("u")) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return result("done")
    }

    fun volumeSet(ctx: Context, percent: Int): JSONObject {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, volumeIndexForPercent(percent, max), AudioManager.FLAG_SHOW_UI)
        return result("done")
    }

    fun mute(ctx: Context, on: Boolean): JSONObject {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
        return result("done")
    }

    private fun policyGranted(ctx: Context): Boolean =
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted

    private fun openPolicySettings(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun ringerMode(ctx: Context, mode: String): JSONObject {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return try {
            when (mode.lowercase()) {
                "silent" -> {
                    if (!policyGranted(ctx)) { openPolicySettings(ctx); return result("needs_permission", "Allow Do Not Disturb access for Jex, then ask again") }
                    am.ringerMode = AudioManager.RINGER_MODE_SILENT
                }
                "vibrate" -> am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                else -> am.ringerMode = AudioManager.RINGER_MODE_NORMAL
            }
            result("done")
        } catch (e: SecurityException) { openPolicySettings(ctx); result("needs_permission", "Allow Do Not Disturb access for Jex") }
    }

    fun dnd(ctx: Context, on: Boolean): JSONObject {
        if (!policyGranted(ctx)) { openPolicySettings(ctx); return result("needs_permission", "Allow Do Not Disturb access for Jex, then ask again") }
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        return result("done")
    }

    fun brightnessChange(ctx: Context, direction: String): JSONObject {
        if (!Settings.System.canWrite(ctx)) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return result("needs_permission", "Allow Jex to modify system settings, then ask again")
        }
        return try {
            val cur = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            val next = (if (direction.lowercase().startsWith("u")) cur + 51 else cur - 51).coerceIn(10, 255)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, next)
            result("done")
        } catch (e: Exception) { result("failed", "Couldn't change brightness") }
    }

    /** Wi-Fi / Bluetooth / airplane cannot be flipped silently: drive the Quick Settings panel through accessibility. */
    suspend fun quickToggle(ctx: Context, kind: String, on: Boolean, driver: ScreenDriver = ScreenDrivers.current): JSONObject {
        fun fallback(): JSONObject {
            val action = when (kind) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                else -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            }
            try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (ignored: Exception) {}
            return result("needs_user_tap", "I opened the settings page; please tap the switch yourself")
        }
        if (!driver.isAvailable()) return fallback()
        driver.globalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        delay(800)
        val labels = driver.readScreenLines(60, 60).map { it.substringAfter("] ") }
        val tile = QuickSettingsTiles.findTile(labels, kind)
        if (tile == null) { driver.globalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK); return fallback() }
        val isOn = QuickSettingsTiles.looksOn(tile)
        if (isOn != on) {
            driver.clickText(tile)
            delay(600)
        }
        val after = driver.readScreenLines(60, 60).map { it.substringAfter("] ") }.let { QuickSettingsTiles.findTile(it, kind) }
        driver.globalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        val verified = after != null && QuickSettingsTiles.looksOn(after) == on
        return if (verified || isOn == on) result("done") else result("needs_user_tap", "I tapped the tile but couldn't confirm the new state")
    }
}
