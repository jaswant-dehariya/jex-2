package com.Jex.assistant.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.Jex.assistant.action.JexAccessibilityService
import com.Jex.assistant.agent.layers.TaskTools
import com.Jex.assistant.callagent.CallAgent
import com.Jex.assistant.callagent.CallState
import com.Jex.assistant.data.JexAppState
import com.Jex.assistant.notify.JexNotificationListener
import com.Jex.assistant.share.ScreenShareController
import com.Jex.assistant.ui.components.JexButton
import com.Jex.assistant.ui.components.JexButtonStyle
import com.Jex.assistant.ui.components.JexSectionHeader
import com.Jex.assistant.ui.components.JexSettingsRow
import com.Jex.assistant.ui.fx.OverlayEdgeGlowController
import com.Jex.assistant.ui.nav.Routes
import com.Jex.assistant.ui.theme.JexType
import com.Jex.assistant.ui.theme.LocalJexColors

private fun Context.openSettings(action: String, pkg: Boolean = false) {
    val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (pkg) i.data = Uri.parse("package:$packageName")
    try { startActivity(i) } catch (ignored: Exception) {}
}

/** Prominent disclosure shown BEFORE sending the user to Accessibility settings. */
fun NavGraphBuilder.registerAccessibilityDisclosureRoute(nav: NavHostController) {
    composable(Routes.ACCESSIBILITY_DISCLOSURE) {
        val ctx = LocalContext.current
        val c = LocalJexColors.current
        JexScreenColumn("Screen control", onBack = { nav.popBackStack() }) {
            SectionCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("What this does", style = JexType.title.copy(color = c.textPrimary))
                    Text(
                        "Jex AI uses Android's Accessibility service to read what is on your screen and to tap, type and scroll ONLY when you ask it to " +
                            "(for example 'open WhatsApp and search Rahul').", style = JexType.body.copy(color = c.textSecondary)
                    )
                    Text("What it never does", style = JexType.title.copy(color = c.textPrimary))
                    Text(
                        "It does not run in the background on its own, does not store or upload what it reads, never enters passwords, never makes payments " +
                            "and always asks before anything irreversible. You can turn it off any time in Android Settings.", style = JexType.body.copy(color = c.textSecondary)
                    )
                    JexButton("I understand, open settings", { ctx.openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) })
                }
            }
        }
    }
}

@Composable
fun FlavorSettingsRows(appState: JexAppState, nav: NavHostController) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    @Suppress("UNUSED_VARIABLE") val t = tick
    JexSectionHeader("Phone control")
    SectionCard {
        Column {
            JexSettingsRow(
                Icons.Filled.Accessibility, "Screen control", subtitle = "Lets Jex tap, type and scroll when you ask",
                value = if (JexAccessibilityService.isEnabled(ctx)) "On" else "Off", onClick = { nav.navigate(Routes.ACCESSIBILITY_DISCLOSURE) }
            )
            JexSettingsRow(
                Icons.Filled.Notifications, "Read notifications aloud", subtitle = "Only while a voice session is running",
                switchValue = appState.readNotifications, onSwitch = { appState.applyReadNotifications(it) }
            )
            JexSettingsRow(
                Icons.Filled.Notifications, "Read sensitive messages", subtitle = "OTPs and bank alerts stay hidden unless on",
                switchValue = appState.readSensitiveAloud, onSwitch = { appState.applyReadSensitiveAloud(it) }
            )
        }
    }
}

@Composable
fun FlavorPermissionRows(tick: Int) {
    val ctx = LocalContext.current
    JexSectionHeader("Phone control")
    SectionCard {
        Column {
            PermissionRow("Screen control (Accessibility)", "Tap, type and scroll when you ask", if (JexAccessibilityService.isEnabled(ctx)) PermStatus.GRANTED else PermStatus.DENIED, "Set up") {
                ctx.openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            }
            PermissionRow("Notification access", "To read notifications aloud", if (JexNotificationListener.isEnabled(ctx)) PermStatus.GRANTED else PermStatus.OPTIONAL, "Set up") {
                ctx.openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            }
            PermissionRow("Display over other apps", "Edge glow on every screen", if (OverlayEdgeGlowController.canDraw(ctx)) PermStatus.GRANTED else PermStatus.OPTIONAL, "Allow") {
                ctx.openSettings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg = true)
            }
            PermissionRow("Do Not Disturb access", "Silent mode and DND", if ((ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).isNotificationPolicyAccessGranted) PermStatus.GRANTED else PermStatus.OPTIONAL, "Allow") {
                ctx.openSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            }
            PermissionRow("Modify system settings", "Screen brightness", if (Settings.System.canWrite(ctx)) PermStatus.GRANTED else PermStatus.OPTIONAL, "Allow") {
                ctx.openSettings(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg = true)
            }
        }
    }
}

@Composable
fun FlavorVoiceExtras(appState: JexAppState, nav: NavHostController) {
    val ctx = LocalContext.current
    val sharing by ScreenShareController.active.collectAsState()
    val call by CallAgent.ui.collectAsState()
    val tasks by TaskTools.manager(ctx).active.collectAsState()
    val c = LocalJexColors.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (sharing) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("● LIVE: sharing your screen", style = JexType.label.copy(color = c.lagoon), modifier = Modifier.padding(top = 12.dp))
                JexButton("Stop sharing", { ScreenShareController.stop(ctx) }, style = JexButtonStyle.SECONDARY, icon = Icons.Filled.ScreenShare)
            }
        }
        if (call.active) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("On a call with ${call.contact} (${call.state.name.lowercase()})", style = JexType.label.copy(color = c.accent), modifier = Modifier.padding(top = 12.dp))
                JexButton("End call", { CallAgent.endNow() }, style = JexButtonStyle.SECONDARY, icon = Icons.Filled.Call)
            }
        }
        tasks.forEach { t ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Task ${t.id}: ${t.goal.take(28)} · ${t.state.name.lowercase()}", style = JexType.caption.copy(color = c.textSecondary), modifier = Modifier.padding(top = 14.dp))
                JexButton("Cancel", { TaskTools.manager(ctx).cancel(t.id) }, style = JexButtonStyle.TEXT)
            }
        }
        if (tasks.isNotEmpty()) JexButton("Stop everything", { TaskTools.manager(ctx).cancelAll() }, style = JexButtonStyle.SECONDARY)
    }
}

@Composable
fun FlavorDebugSection() {
    val ctx = LocalContext.current
    val c = LocalJexColors.current
    JexSectionHeader("Task log (last 20, no message contents)")
    SectionCard {
        Column(Modifier.padding(16.dp)) {
            val lines = TaskTools.manager(ctx).historyLines()
            if (lines.isEmpty()) Text("No tasks yet.", style = JexType.caption.copy(color = c.textSecondary))
            lines.asReversed().forEach { Text(it, style = JexType.caption.copy(color = c.textSecondary), modifier = Modifier.padding(bottom = 4.dp)) }
        }
    }
    JexSectionHeader("Calls: reality check")
    SectionCard { Text(CallAgent.REALITY_CHECK, style = JexType.caption.copy(color = c.textSecondary), modifier = Modifier.padding(16.dp)) }
}

fun flavorQuickTiles(): List<QuickTile> = listOf(
    QuickTile("Torch", "Torch jala do", Icons.Filled.FlashlightOn) { cx, _ ->
        com.Jex.assistant.action.SystemToggles.flashlight(cx, true)
    },
    QuickTile("Volume up", "Volume badha do", Icons.Filled.VolumeUp) { cx, _ ->
        com.Jex.assistant.action.SystemToggles.volumeChange(cx, "up")
    },
    QuickTile("Wi-Fi settings", "Wi-Fi band karo", Icons.Filled.Wifi) { cx, _ -> cx.openSettings(Settings.ACTION_WIFI_SETTINGS) },
    QuickTile("Overlay glow", "Edge glow permission", Icons.Filled.Layers) { cx, _ -> cx.openSettings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg = true) }
)
