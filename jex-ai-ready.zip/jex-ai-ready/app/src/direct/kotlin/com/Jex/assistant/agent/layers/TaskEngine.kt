package com.Jex.assistant.agent.layers

import android.content.Context
import com.Jex.assistant.action.ScreenDriver
import com.Jex.assistant.action.ScreenDrivers
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

enum class Risk { SAFE, NEEDS_CONFIRM }
enum class TaskRunState { PLANNING, RUNNING, WAITING_FOR_USER, PAUSED, COMPLETED, FAILED, CANCELLED }

data class PlanStep(val tool: String, val args: JSONObject, val expectation: String? = null, val risk: Risk = Risk.SAFE)

/** Shared confirmation policy for every part (Part 21). */
object ConfirmationPolicy {
    private val irreversibleTools = setOf("whatsapp_message", "sms_send", "call_contact", "whatsapp_call", "whatsapp_video_call", "contact_delete", "notification_reply", "call_and_talk", "execute_social_media_task")

    fun riskOf(tool: String): Risk = if (tool in irreversibleTools) Risk.NEEDS_CONFIRM else Risk.SAFE

    /** A clear imperative in the user's own request counts as confirmation for exactly that action. */
    private val imperatives = listOf("bhej do", "bhejo", "bhej de", "send it", "send kar", "call karo", "call kar", "phone kar", "laga do", "kar do", "delete kar", "hata do", "post kar", "reply kar do", "go ahead", "yes", "haan")
    fun hasClearImperative(goal: String): Boolean = imperatives.any { goal.lowercase().contains(it) }

    fun allowed(step: PlanStep, goal: String, confirmedKeys: Set<String>): Boolean =
        step.risk == Risk.SAFE || hasClearImperative(goal) || step.tool in confirmedKeys
}

/** Verifier: checks an expectation against the screen. Pure over a list of screen lines. */
object StepVerifier {
    fun check(expectation: String?, lines: List<String>): Boolean {
        if (expectation.isNullOrBlank()) return true
        val e = expectation.trim()
        if (e.startsWith("gone:")) return lines.none { it.contains(e.removePrefix("gone:").trim(), true) }
        if (e.startsWith("text:")) return lines.any { it.contains(e.removePrefix("text:").trim(), true) }
        return lines.any { it.contains(e, true) }
    }
}

/** Watcher: spots blockers and decides whether the task must pause. */
object BlockerWatch {
    private val words = listOf("captcha", "i'm not a robot", "verification code", "enter otp", "two-factor", "log in to continue", "sign in to continue", "allow access")
    fun blockerIn(lines: List<String>): String? = lines.firstOrNull { l -> words.any { l.contains(it, true) } }
}

data class TaskSnapshot(val id: String, val goal: String, val state: TaskRunState)

class TaskRun(val id: String, val goal: String) {
    @Volatile var state = TaskRunState.PLANNING
    @Volatile var plan: List<PlanStep> = emptyList()
    @Volatile var stepIndex = 0
    @Volatile var uiActions = 0
    @Volatile var lastActivity = System.currentTimeMillis()
    @Volatile var result: String = ""
    val layerLog = ArrayList<String>()
    var job: Job? = null
    val confirmed = HashSet<String>()
    @Volatile var foreground = true
    fun log(s: String) { synchronized(layerLog) { layerLog.add(s); if (layerLog.size > 60) layerLog.removeAt(0) } }
}

/** Executes a single plan step; production version routes through DirectToolRunner. Replaceable in tests. */
fun interface StepExecutor { suspend fun run(step: PlanStep): JSONObject }

/**
 * Up to 3 tasks at once, ONE screen lock (foreground task has priority), step budget, inactivity timeout,
 * kill switch and a persisted log of the last 20 tasks WITHOUT message contents.
 */
class TaskManager(
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
    private val driverProvider: () -> ScreenDriver = { ScreenDrivers.current },
    private val executor: StepExecutor,
    private val planner: suspend (String) -> List<PlanStep>,
    private val now: () -> Long = { System.currentTimeMillis() },
    private val onSpeak: (String) -> Unit = {},
    private val onFinished: (TaskRun) -> Unit = {}
) {
    companion object {
        const val MAX_CONCURRENT = 3
        const val MAX_PLAN_STEPS = 25
        const val UI_BUDGET = 60
        const val INACTIVITY_MS = 5 * 60 * 1000L
        const val RETRIES = 2
        val UI_TOOLS = setOf("open_app", "go_home", "go_back", "recent_apps", "open_notifications", "quick_settings", "take_screenshot", "read_screen", "click_text", "click_any_button", "scroll", "swipe", "type_text", "tap_at", "whatsapp_open", "whatsapp_search", "whatsapp_message", "whatsapp_call", "whatsapp_video_call", "sms_send", "set_wifi", "set_bluetooth", "airplane_mode", "take_photo")
    }

    private val uiLock = Mutex()
    private val runs = ConcurrentHashMap<String, TaskRun>()
    private val counter = AtomicInteger(0)
    private val _active = MutableStateFlow<List<TaskSnapshot>>(emptyList())
    val active: StateFlow<List<TaskSnapshot>> = _active
    private val history = ArrayDeque<String>() // goal, steps, result; no message contents

    fun runningCount() = runs.values.count { !it.state.isTerminal() }
    fun get(id: String?): TaskRun? = if (id.isNullOrBlank()) runs.values.lastOrNull() else runs[id]
    fun all(): List<TaskRun> = runs.values.sortedBy { it.id }
    fun historyLines(): List<String> = synchronized(history) { history.toList() }

    private fun TaskRunState.isTerminal() = this == TaskRunState.COMPLETED || this == TaskRunState.FAILED || this == TaskRunState.CANCELLED

    fun start(goal: String, foreground: Boolean = true): JSONObject {
        if (runningCount() >= MAX_CONCURRENT) return ToolResults.status("too_many_tasks", "Three tasks are already running")
        val id = "t" + counter.incrementAndGet()
        val run = TaskRun(id, goal).also { it.foreground = foreground }
        runs[id] = run
        publish()
        run.job = scope.launch { execute(run) }
        return JSONObject().put("status", "started").put("task_id", id)
    }

    private fun publish() { _active.value = runs.values.filter { !it.state.isTerminal() }.sortedBy { it.id }.map { TaskSnapshot(it.id, it.goal, it.state) } }

    private suspend fun execute(run: TaskRun) {
        try {
            run.log("PLANNER: planning")
            val steps = planner(run.goal).take(MAX_PLAN_STEPS)
            if (steps.isEmpty()) { finish(run, TaskRunState.FAILED, "No plan could be made"); return }
            run.plan = steps
            run.state = TaskRunState.RUNNING
            publish()
            var i = 0
            while (i < run.plan.size) {
                if (run.state == TaskRunState.CANCELLED) return
                while (run.state == TaskRunState.PAUSED || run.state == TaskRunState.WAITING_FOR_USER) {
                    delay(250)
                    if (now() - run.lastActivity > INACTIVITY_MS) { finish(run, TaskRunState.FAILED, "Timed out waiting"); return }
                    if (run.state == TaskRunState.CANCELLED) return
                }
                run.stepIndex = i
                val step = run.plan[i]
                if (!ConfirmationPolicy.allowed(step, run.goal, run.confirmed)) {
                    run.state = TaskRunState.WAITING_FOR_USER
                    run.log("EXECUTOR: ${step.tool} needs the user's yes")
                    onSpeak("Ask the user a short yes/no question before doing '${step.tool}'. Do not do it until they say yes.")
                    publish()
                    continue
                }
                val isUi = step.tool in UI_TOOLS
                if (isUi && run.uiActions >= UI_BUDGET) { finish(run, TaskRunState.FAILED, "Step budget reached"); return }
                var attempt = 0
                var ok = false
                var last = JSONObject()
                while (attempt <= RETRIES && !ok) {
                    attempt++
                    last = if (isUi) uiLock.withLock { run.uiActions++; executor.run(step) } else executor.run(step)
                    run.lastActivity = now()
                    val status = last.optString("status", last.optString("result"))
                    val failed = status == "failed" || status == "element_not_found" || last.has("error")
                    if (status == "needs_permission" || status == "needs_user_tap" || status == "accessibility_not_enabled") { run.log("EXECUTOR: ${step.tool} -> $status"); break }
                    if (!failed) {
                        // VERIFIER: re-observe and check the expectation
                        val lines = if (step.expectation != null) { delay(300); driverProvider().readScreenLines(60, 60) } else emptyList()
                        ok = StepVerifier.check(step.expectation, lines)
                        run.log("VERIFIER: ${step.tool} ${if (ok) "ok" else "mismatch"}")
                        // WATCHER: blockers pause the task
                        BlockerWatch.blockerIn(lines)?.let { run.state = TaskRunState.WAITING_FOR_USER; run.log("WATCHER: blocker, waiting for the user"); publish(); onSpeak("The screen needs the user (login/captcha/code). Tell them briefly and wait.") }
                    }
                }
                if (!ok) { finish(run, TaskRunState.FAILED, "Step '${step.tool}' did not work: ${last.optString("status", "failed")}"); return }
                i++
            }
            finish(run, TaskRunState.COMPLETED, "Done")
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            finish(run, TaskRunState.FAILED, "Unexpected error")
        }
    }

    private fun finish(run: TaskRun, state: TaskRunState, msg: String) {
        run.state = state
        run.result = msg
        run.log("NARRATOR: $msg")
        synchronized(history) {
            history.addLast("${run.goal.take(60)} | ${run.stepIndex + 1}/${run.plan.size} steps | ${state.name} | $msg")
            while (history.size > 20) history.removeFirst()
        }
        publish()
        onFinished(run)
    }

    fun pause(id: String?): JSONObject { val r = get(id) ?: return ToolResults.status("no_task"); if (r.state == TaskRunState.RUNNING) r.state = TaskRunState.PAUSED; publish(); return ToolResults.status("paused") }
    fun resume(id: String?): JSONObject {
        val r = get(id) ?: return ToolResults.status("no_task")
        if (r.state == TaskRunState.PAUSED || r.state == TaskRunState.WAITING_FOR_USER) { r.state = TaskRunState.RUNNING; r.lastActivity = now() }
        publish(); return ToolResults.status("resumed")
    }
    /** The user said yes to the pending irreversible step. */
    fun confirm(id: String?): JSONObject {
        val r = get(id) ?: return ToolResults.status("no_task")
        r.plan.getOrNull(r.stepIndex)?.let { r.confirmed.add(it.tool) }
        return resume(id)
    }
    fun cancel(id: String?): JSONObject { val r = get(id) ?: return ToolResults.status("no_task"); r.job?.cancel(); finish(r, TaskRunState.CANCELLED, "Cancelled"); return ToolResults.status("cancelled") }
    fun cancelAll(): JSONObject { runs.values.filter { !it.state.isTerminal() }.forEach { it.job?.cancel(); finish(it, TaskRunState.CANCELLED, "Cancelled") }; return ToolResults.status("all_cancelled") }
    fun status(id: String?): JSONObject {
        val r = get(id) ?: return ToolResults.status("no_task")
        return JSONObject().put("task_id", r.id).put("state", r.state.name.lowercase()).put("step", r.stepIndex + 1).put("of", r.plan.size).put("result", r.result)
    }
    fun list(): JSONObject = JSONObject().put("tasks", JSONArray().also { a -> runs.values.forEach { a.put(JSONObject().put("id", it.id).put("goal", it.goal.take(60)).put("state", it.state.name.lowercase())) } })
}
