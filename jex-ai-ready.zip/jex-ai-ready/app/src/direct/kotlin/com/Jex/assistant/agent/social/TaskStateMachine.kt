package com.Jex.assistant.agent.social

enum class TaskState {
    IDLE, OPENING_APP, OBSERVING, RESOLVING_TARGET, VALIDATING_TARGET, EXECUTING_ACTION, WAITING_FOR_UI, VERIFYING,
    NEXT_STEP, RETRY, REOBSERVE, WAITING_FOR_CONFIRMATION, WAITING_FOR_USER, COMPLETED, FAILED, CANCELLED;

    val isTerminal get() = this == COMPLETED || this == FAILED || this == CANCELLED
}

class IllegalTransitionException(from: TaskState, to: TaskState) : IllegalStateException("Illegal transition $from -> $to")

/** moveTo() throws on an illegal transition. FAILED/CANCELLED are reachable from every non-terminal state; terminals never exit. */
class TaskStateMachine {
    var state: TaskState = TaskState.IDLE; private set
    private val _history = mutableListOf(TaskState.IDLE)
    val history: List<TaskState> get() = _history

    companion object {
        private val allowed: Map<TaskState, Set<TaskState>> = mapOf(
            TaskState.IDLE to setOf(TaskState.OPENING_APP),
            TaskState.OPENING_APP to setOf(TaskState.OBSERVING, TaskState.WAITING_FOR_USER),
            TaskState.OBSERVING to setOf(TaskState.RESOLVING_TARGET, TaskState.WAITING_FOR_USER, TaskState.COMPLETED),
            TaskState.RESOLVING_TARGET to setOf(TaskState.VALIDATING_TARGET, TaskState.REOBSERVE, TaskState.WAITING_FOR_USER),
            TaskState.VALIDATING_TARGET to setOf(TaskState.EXECUTING_ACTION, TaskState.WAITING_FOR_CONFIRMATION, TaskState.REOBSERVE),
            TaskState.EXECUTING_ACTION to setOf(TaskState.WAITING_FOR_UI, TaskState.VERIFYING, TaskState.RETRY),
            TaskState.WAITING_FOR_UI to setOf(TaskState.VERIFYING, TaskState.REOBSERVE),
            TaskState.VERIFYING to setOf(TaskState.NEXT_STEP, TaskState.RETRY, TaskState.COMPLETED),
            TaskState.NEXT_STEP to setOf(TaskState.OBSERVING, TaskState.COMPLETED),
            TaskState.RETRY to setOf(TaskState.REOBSERVE, TaskState.OBSERVING),
            TaskState.REOBSERVE to setOf(TaskState.OBSERVING, TaskState.RESOLVING_TARGET),
            TaskState.WAITING_FOR_CONFIRMATION to setOf(TaskState.EXECUTING_ACTION),
            TaskState.WAITING_FOR_USER to setOf(TaskState.OBSERVING, TaskState.REOBSERVE)
        )
        fun canMove(from: TaskState, to: TaskState): Boolean {
            if (from.isTerminal) return false
            if (to == TaskState.FAILED || to == TaskState.CANCELLED) return true
            return allowed[from]?.contains(to) == true
        }
    }

    fun moveTo(next: TaskState) {
        if (!canMove(state, next)) throw IllegalTransitionException(state, next)
        state = next
        _history.add(next)
    }
}
