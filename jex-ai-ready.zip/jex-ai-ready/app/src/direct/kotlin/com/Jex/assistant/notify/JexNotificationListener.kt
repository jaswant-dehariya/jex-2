package com.Jex.assistant.notify

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JexNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification ?: return
        val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0
        val fgs = (n.flags and Notification.FLAG_FOREGROUND_SERVICE) != 0
        val summary = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        if (NotificationRules.shouldSkip(ongoing, fgs, summary, n.category, sbn.packageName, packageName)) return
        val extras = n.extras ?: Bundle()
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        val msgs = ArrayList<String>()
        @Suppress("DEPRECATION")
        extras.getParcelableArray(Notification.EXTRA_MESSAGES)?.forEach { p ->
            (p as? Bundle)?.getCharSequence("text")?.toString()?.let { msgs.add(it) }
        }
        if (title.isBlank() && text.isBlank() && msgs.isEmpty()) return
        val label = try {
            val pm = packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (ignored: Exception) { sbn.packageName }
        val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
        val event = NotificationEvent(
            sbn.id, sbn.key, sbn.packageName, label, title, text, msgs, sbn.postTime, n.category, reply != null
        )
        if (NotificationStore.add(event, reply)) NotificationAnnouncer.onEvent(applicationContext, event)
    }

    companion object {
        fun isEnabled(ctx: Context): Boolean {
            val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
            val me = ComponentName(ctx, JexNotificationListener::class.java)
            return flat.split(':').mapNotNull { ComponentName.unflattenFromString(it) }.any { it == me }
        }
    }
}
