package com.Jex.assistant.action

import com.Jex.assistant.callagent.CallAgent
import org.json.JSONArray

/**
 * One declaration per capability. Descriptions are written FOR THE MODEL (what, when, spoken examples):
 * the model picks the tool from the meaning of what the user said. There is no keyword router anywhere.
 */
object JexToolCatalog {
    private fun d(name: String, desc: String, vararg params: Pair<String, String>, required: List<String> = params.map { it.first }.take(1)) =
        functionDecl(name, desc, params.toMap(), if (params.isEmpty()) emptyList() else required)

    fun declarations(): JSONArray {
        val a = JSONArray()
        listOf(
            d("open_app", "Open an installed app by name. Examples: 'YouTube kholo', 'open camera', 'Chrome chalao'.", "app_name" to "App name"),
            d("go_home", "Go to the home screen. 'home pe jao', 'go home'."),
            d("go_back", "Press Back. 'peeche jao', 'back'."),
            d("recent_apps", "Open recent apps. 'recents dikhao'."),
            d("open_notifications", "Pull down the notification shade. 'notifications kholo'."),
            d("quick_settings", "Open quick settings."),
            d("lock_screen", "Lock the phone. 'screen lock kar do'."),
            d("take_screenshot", "Take a screenshot. 'screenshot le lo'."),
            d("read_screen", "Read what is on the screen (labels, inputs, buttons). 'screen par kya hai', 'what's on my screen'."),
            d("read_screen_detailed", "Read the screen in detail, including input fields with their current text, checkbox state and buttons."),
            d("click_text", "Tap a button or text on screen by its label. 'Send dabao', 'tap Next', 'Search par click karo'.", "text" to "Visible label"),
            d("click_any_button", "Tap the only actionable button on screen; if several exist the tool lists them so you can ask which one."),
            d("scroll", "Scroll the current screen. direction: up, down, left or right. 'neeche scroll karo'.", "direction" to "up, down, left or right"),
            d("swipe", "Swipe the screen with a finger gesture. 'swipe left'.", "direction" to "up, down, left or right"),
            d("type_text", "Type text into the focused input field.", "text" to "Text to type"),
            d("tap_at", "Tap exact screen coordinates (use only when click_text cannot reach it).", "x" to "x pixel", "y" to "y pixel", required = listOf("x", "y")),
            d("whatsapp_open", "Open WhatsApp."),
            d("whatsapp_search", "Open WhatsApp and search for a chat.", "name" to "Contact or chat name"),
            d("whatsapp_message", "Send a WhatsApp message to a contact. Use when the user clearly says 'bhej do' / 'send'. 'Rahul ko WhatsApp karo ki main late hoon'.", "name" to "Contact name or number", "text" to "Message", required = listOf("name", "text")),
            d("whatsapp_call", "Start a WhatsApp voice call to a contact.", "name" to "Contact name"),
            d("whatsapp_video_call", "Start a WhatsApp video call to a contact.", "name" to "Contact name"),
            d("call_contact", "Place a normal phone call. 'Mummy ko call karo', 'call 98765 43210'.", "name_or_number" to "Contact name or number"),
            d("sms_send", "Send an SMS to a contact. Only when the user clearly asks to send.", "name_or_number" to "Contact name or number", "text" to "Message", required = listOf("name_or_number", "text")),
            d("contacts_show", "Open the Contacts app."),
            d("contact_save", "Save a contact (name and number).", "name" to "Name", "number" to "Phone number", required = listOf("name", "number")),
            d("contact_delete", "Delete a saved contact. Irreversible: confirm unless the user was clear.", "name" to "Name"),
            d("contact_lookup", "Find a contact's phone number so you can say it aloud. 'Rahul ka number batao'.", "name" to "Name"),
            d("set_wifi", "Turn Wi-Fi on or off.", "on" to "true or false"),
            d("set_bluetooth", "Turn Bluetooth on or off.", "on" to "true or false"),
            d("set_flashlight", "Turn the torch on or off. 'torch jala do', 'flashlight off'.", "on" to "true or false"),
            d("volume_change", "Make the volume louder or quieter. direction: up or down.", "direction" to "up or down"),
            d("volume_set", "Set the media volume to a percent from 0 to 100.", "percent" to "0-100"),
            d("mute", "Mute or unmute the sound.", "on" to "true or false"),
            d("set_ringer_mode", "Set ringer mode: silent, vibrate or normal.", "mode" to "silent, vibrate or normal"),
            d("brightness_change", "Make the screen brighter or dimmer. direction: up or down.", "direction" to "up or down"),
            d("airplane_mode", "Turn airplane mode on or off.", "on" to "true or false"),
            d("dnd", "Turn Do Not Disturb on or off.", "on" to "true or false"),
            d("take_photo", "Take a photo with the phone camera. camera: back or front.", "camera" to "back or front", required = emptyList()),
            d("read_recent_notifications", "Read the user's recent notifications. 'recent notifications batao'.", "limit" to "How many, default 5", "app" to "Optional app name", required = emptyList()),
            d("notifications_toggle", "Turn reading new notifications aloud on or off.", "on" to "true or false"),
            d("notification_reply", "Reply to a notification by key. Send only when the user clearly said to send ('bhej do'); otherwise ask 'bhej du?'.", "key" to "Notification key", "text" to "Reply text", required = listOf("key", "text")),
            d("screen_share", "Start, stop or check live screen sharing so you can see the user's screen. Only the user can stop it. action: start, stop or status.", "action" to "start, stop or status"),
            d("guide_form", "Guide the user through a form field by field. action: start, pause, resume, skip or stop. mode: coach (default) or fill.", "action" to "start, pause, resume, skip or stop", "mode" to "coach or fill", required = listOf("action")),
            d("run_task", "Run a multi-step goal in the background, for example 'WhatsApp kholo, Ayush ko dhundo, torch on karo'. The planner breaks it down.", "goal" to "The user's goal in their own words"),
            d("task_status", "Check a running task.", "task_id" to "Task id (optional)", required = emptyList()),
            d("pause_task", "Pause a task.", "task_id" to "Task id (optional)", required = emptyList()),
            d("resume_task", "Resume a task.", "task_id" to "Task id (optional)", required = emptyList()),
            d("confirm_task", "The user said yes to the step a task was waiting on. Call only after an explicit yes.", "task_id" to "Task id (optional)", required = emptyList()),
            d("cancel_task", "Cancel a task. Set all to true for 'sab cancel'.", "task_id" to "Task id (optional)", "all" to "true to cancel all", required = emptyList()),
            d("list_tasks", "List running tasks."),
            d("stop_everything", "Kill switch: 'sab roko'. Cancels every task."),
            CallAgent.declaration,
            d("execute_social_media_task", "Create a post, reel or story on Instagram or Facebook with media the user shared to Jex AI. It stops before publishing and waits for confirmation.",
                "platform" to "instagram or facebook", "action" to "create_post, create_reel, create_story or text_post", "media_uri" to "content:// URI of shared media", "caption" to "Caption", "mode" to "publish or draft", "target_account" to "Optional account", required = listOf("platform", "action")),
            d("social_media_task_control", "Control a social task. Only call confirm after the user explicitly said yes. command: confirm, reject, resume, cancel or status.", "command" to "confirm, reject, resume, cancel or status", "task_id" to "Task id", required = listOf("command")),
            d("execute_whatsapp_task", "WhatsApp helper. action: read_unread, send_message, read_chat, search_chat, mute_chat, unmute_chat, mark_read.", "action" to "Action name", "contact" to "Contact", "text" to "Message text", required = listOf("action")),
            d("whatsapp_task_control", "Control a WhatsApp task. command: cancel or status.", "command" to "cancel or status")
        ).forEach { a.put(it) }
        CommonTools.declarations().forEach { a.put(it) }
        return a
    }
}
