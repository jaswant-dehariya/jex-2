package com.Jex.assistant.agent.whatsapp

import android.content.Context
import com.Jex.assistant.action.AutoSend
import com.Jex.assistant.action.CommIntents
import com.Jex.assistant.action.ContactResolver
import com.Jex.assistant.action.ContactResult
import com.Jex.assistant.action.ScreenDriver
import com.Jex.assistant.action.ScreenDrivers
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.notify.NotificationStore
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

enum class WaAction { READ_UNREAD, SEND_MESSAGE, READ_CHAT, SEARCH_CHAT, MUTE_CHAT, UNMUTE_CHAT, MARK_READ }

object WhatsAppAgent {
    private const val WA = "com.whatsapp"

    suspend fun execute(ctx: Context, args: JSONObject, driver: ScreenDriver = ScreenDrivers.current): JSONObject {
        val action = WaAction.entries.firstOrNull { it.name.equals(args.optString("action"), true) } ?: return ToolResults.error("unknown action")
        val contact = args.optString("contact")
        return when (action) {
            // reads the notification buffer, never opens the app
            WaAction.READ_UNREAD -> {
                val arr = JSONArray()
                NotificationStore.recent(15).filter { it.packageName.startsWith(WA) }.forEach {
                    arr.put(JSONObject().put("from", it.sender).put("text", (it.messages.lastOrNull() ?: it.text).take(160)))
                }
                JSONObject().put("status", "ok").put("unread", arr)
            }
            WaAction.SEND_MESSAGE -> {
                val text = args.optString("text")
                if (text.isBlank()) return ToolResults.error("text missing")
                val num = resolveNumber(ctx, contact) ?: return ToolResults.status("contact_not_found")
                if (num == AMBIGUOUS) return ToolResults.status("contact_ambiguous", "Several contacts match; ask which one")
                if (!CommIntents.openWhatsAppComposer(ctx, num, text)) return ToolResults.status("failed")
                JSONObject().put("status", AutoSend.tapSend(driver, whatsApp = true))
            }
            WaAction.READ_CHAT, WaAction.SEARCH_CHAT, WaAction.MUTE_CHAT, WaAction.UNMUTE_CHAT, WaAction.MARK_READ -> {
                if (!driver.isAvailable()) return ToolResults.status("accessibility_not_enabled")
                CommIntents.whatsAppPackage(ctx)?.let { com.Jex.assistant.action.AppLauncher.launch(ctx, it) } ?: return ToolResults.status("whatsapp_not_installed")
                delay(1800)
                if (contact.isNotBlank()) {
                    driver.clickText("Search"); delay(500); driver.typeText(contact); delay(900)
                    if (action != WaAction.SEARCH_CHAT) { if (!driver.clickText(contact)) return ToolResults.status("element_not_found") ; delay(900) }
                }
                when (action) {
                    WaAction.READ_CHAT -> JSONObject().put("status", "ok").put("screen", JSONArray(driver.readScreenLines(50, 80)))
                    WaAction.MUTE_CHAT -> JSONObject().put("status", if (driver.clickText("More options") && driver.clickText("Mute notifications")) "done" else "needs_user_tap")
                    WaAction.UNMUTE_CHAT -> JSONObject().put("status", if (driver.clickText("More options") && driver.clickText("Unmute notifications")) "done" else "needs_user_tap")
                    WaAction.MARK_READ -> JSONObject().put("status", if (driver.clickText("Mark as read")) "done" else "needs_user_tap")
                    else -> JSONObject().put("status", "done")
                }
            }
        }
    }

    private const val AMBIGUOUS = "__ambiguous__"

    /** Two different people matching the query fail with contact_ambiguous instead of guessing. */
    private fun resolveNumber(ctx: Context, contact: String): String? {
        val matches = ContactResolver.matches(ctx, contact)
        if (matches.size > 1 && matches.map { it.number.filter(Char::isDigit) }.distinct().size > 1 &&
            matches.none { it.name.equals(contact.trim(), true) }
        ) return AMBIGUOUS
        return when (val r = ContactResolver.lookup(ctx, contact)) {
            is ContactResult.Found -> r.number
            else -> null
        }
    }
}
