package com.Jex.assistant.action

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Reads the screen and performs taps/typing/scrolling. Only acts when the user asked Jex to. */
class JexAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------------------------------------------------------------- reading

    private fun label(n: AccessibilityNodeInfo): String {
        val t = n.text?.toString()?.trim().orEmpty()
        if (t.isNotEmpty()) return t
        val d = n.contentDescription?.toString()?.trim().orEmpty()
        if (d.isNotEmpty()) return d
        return n.hintText?.toString()?.trim().orEmpty()
    }

    /** BFS over the active window: unique lines like "[input] Search". */
    fun readScreen(maxElements: Int = 40, maxLabelLength: Int = 40): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = LinkedHashSet<String>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty() && out.size < maxElements) {
            val n = queue.removeFirst()
            val l = label(n).take(maxLabelLength)
            if (l.isNotEmpty() && n.isVisibleToUser) {
                val kind = when {
                    n.isEditable -> "[input]"
                    n.isClickable -> "[button]"
                    else -> "[text]"
                }
                out.add("$kind $l")
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return out.toList()
    }

    /** Every visible label, inputs with their hint/current text, checkbox state, buttons. */
    fun readScreenDetailed(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = LinkedHashSet<String>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty() && out.size < 80) {
            val n = queue.removeFirst()
            if (n.isVisibleToUser) {
                val hint = n.hintText?.toString()?.trim().orEmpty()
                val txt = n.text?.toString()?.trim().orEmpty()
                val l = label(n).take(80)
                when {
                    n.isEditable -> {
                        val name = (hint.ifEmpty { n.contentDescription?.toString().orEmpty() }).ifEmpty { "field" }.take(60)
                        val pw = n.isPassword
                        val state = if (pw) (if (txt.isEmpty()) "(empty)" else "(filled, hidden)") else if (txt.isEmpty() || txt == hint) "(empty)" else "(filled: ${txt.take(40)})"
                        out.add("[input] $name $state")
                    }
                    n.isCheckable -> out.add("[check] $l (${if (n.isChecked) "checked" else "unchecked"})")
                    n.isClickable && l.isNotEmpty() -> out.add("[button] $l")
                    l.isNotEmpty() -> out.add("[text] $l")
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return out.toList()
    }

    fun actionableLabels(): List<String> {
        val root = rootInActiveWindow ?: return emptyList()
        val out = LinkedHashSet<String>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty() && out.size < 40) {
            val n = queue.removeFirst()
            if (n.isClickable && n.isVisibleToUser) label(n).takeIf { it.isNotEmpty() }?.let { out.add(it.take(40)) }
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return out.toList()
    }

    // ---------------------------------------------------------------- acting

    private fun findClickableNode(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val q = text.trim()
        if (q.isEmpty()) return null
        val matches = root.findAccessibilityNodeInfosByText(q).orEmpty()
        val exact = matches.firstOrNull { label(it).equals(q, ignoreCase = true) }
        val node = exact ?: matches.firstOrNull() ?: findByDescription(root, q) ?: return null
        var cur: AccessibilityNodeInfo? = node
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable) return cur
            cur = cur.parent
            hops++
        }
        return node
    }

    private fun findByDescription(root: AccessibilityNodeInfo, q: String): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n.contentDescription?.toString()?.contains(q, ignoreCase = true) == true) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    fun clickText(text: String): Boolean {
        val node = findClickableNode(text) ?: return false
        if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect(); node.getBoundsInScreen(r)
        return r.width() > 0 && tapNow(r.centerX().toFloat(), r.centerY().toFloat())
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: firstEditable(root) ?: return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun firstEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n.isEditable) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    private fun firstScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { queue.add(it) }
        }
        return null
    }

    suspend fun scroll(direction: String): String {
        val root = rootInActiveWindow ?: return "nothing_scrollable"
        val node = firstScrollable(root)
        if (node != null) {
            val action = if (direction == "up" || direction == "left") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            if (node.performAction(action)) return "scrolled"
        }
        return if (swipe(if (direction == "down") "up" else if (direction == "up") "down" else direction)) "scrolled" else "nothing_scrollable"
    }

    /** direction is the finger movement: "up" moves the finger up. */
    suspend fun swipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val p = Path()
        when (direction) {
            "up" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }
            "down" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "left" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "right" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 320)
    }

    suspend fun tapAt(x: Int, y: Int): Boolean {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return gesture(p, 60)
    }

    private fun tapNow(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    private suspend fun gesture(path: Path, durationMs: Long): Boolean = suspendCancellableCoroutine { cont ->
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!ok && cont.isActive) cont.resume(false)
    }

    companion object {
        @Volatile var instance: JexAccessibilityService? = null

        fun isEnabled(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val me = ComponentName(ctx, JexAccessibilityService::class.java).flattenToString()
            return enabled.split(':').any { it.equals(me, ignoreCase = true) }
        }
    }
}
