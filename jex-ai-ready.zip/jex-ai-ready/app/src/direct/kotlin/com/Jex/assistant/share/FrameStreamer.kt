package com.Jex.assistant.share

import android.graphics.Bitmap
import com.Jex.assistant.vision.FrameMath
import com.Jex.assistant.vision.FrameSourceArbiter
import com.Jex.assistant.vision.VisionController
import com.Jex.assistant.voice.VoiceSessionManager

/** Pure frame-skipping rules for screen share (unit-tested). */
object FrameDiff {
    const val GRID = 16
    const val THRESHOLD = 0.02f
    const val MAX_GAP_MS = 3000L

    /** Mean absolute luminance difference of two GRID*GRID samples, 0..1. */
    fun difference(a: IntArray, b: IntArray): Float {
        if (a.size != b.size || a.isEmpty()) return 1f
        var sum = 0L
        for (i in a.indices) sum += kotlin.math.abs(a[i] - b[i])
        return sum / (a.size * 255f)
    }

    fun shouldSend(diff: Float, nowMs: Long, lastSentMs: Long, minIntervalMs: Long): Boolean {
        if (lastSentMs > 0 && nowMs - lastSentMs < minIntervalMs) return false
        return diff >= THRESHOLD || lastSentMs <= 0 || nowMs - lastSentMs >= MAX_GAP_MS
    }

    fun sample(bmp: Bitmap): IntArray {
        val out = IntArray(GRID * GRID)
        for (y in 0 until GRID) for (x in 0 until GRID) {
            val px = bmp.getPixel(((x + 0.5f) / GRID * bmp.width).toInt().coerceIn(0, bmp.width - 1), ((y + 0.5f) / GRID * bmp.height).toInt().coerceIn(0, bmp.height - 1))
            out[y * GRID + x] = ((px shr 16 and 0xFF) * 299 + (px shr 8 and 0xFF) * 587 + (px and 0xFF) * 114) / 1000
        }
        return out
    }

    /** True when the frame is (almost) fully black: a FLAG_SECURE window. */
    fun isBlack(sample: IntArray): Boolean = sample.isNotEmpty() && sample.maxOrNull()!! < 8
}

/** Called on the capture thread for each screen bitmap. Drops frames instead of queueing. */
class FrameStreamer {
    private var last: IntArray? = null
    private var lastSentMs = 0L
    private var intervalMs = 1000L
    @Volatile var secureWindowSeen = false

    fun onFrame(bmp: Bitmap, nowMs: Long = System.currentTimeMillis()) {
        if (!VoiceSessionManager.isLive) return
        val s = FrameDiff.sample(bmp)
        secureWindowSeen = FrameDiff.isBlack(s)
        val diff = last?.let { FrameDiff.difference(it, s) } ?: 1f
        if (!FrameDiff.shouldSend(diff, nowMs, lastSentMs, intervalMs)) return
        last = s
        lastSentMs = nowMs
        if (!FrameSourceArbiter.allowed(FrameSourceArbiter.Source.SCREEN)) return
        val jpeg = VisionController.encode(bmp.copy(Bitmap.Config.ARGB_8888, false), 0, 1024, 60)
        VoiceSessionManager.sendVideoFrame(jpeg)
        intervalMs = FrameMath.adaptiveInterval(intervalMs, busy = VoiceSessionManager.isSpeaking())
    }
}
