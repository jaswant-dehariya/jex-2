package com.Jex.assistant.share

import com.Jex.assistant.action.ScreenDriver
import com.Jex.assistant.action.ScreenDrivers
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.voice.VoiceSessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Drives guided form mode: announces fields one by one and keeps watching until the form is done. */
object FormGuideController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var machine = FormGuideMachine()
    @Volatile var mode = "coach"

    fun handle(action: String, mode: String, driver: ScreenDriver = ScreenDrivers.current, say: (String) -> Unit = { VoiceSessionManager.say(it) }): JSONObject {
        if (!driver.isAvailable()) return ToolResults.status("accessibility_not_enabled")
        this.mode = if (mode == "fill") "fill" else "coach"
        return when (action.lowercase()) {
            "start" -> { start(driver, say); ToolResults.status("guiding") }
            "pause" -> { machine.pause(); ToolResults.status("paused") }
            "resume" -> { machine.resume(); ToolResults.status("guiding") }
            "skip" -> { machine.skip(); ToolResults.status("skipped") }
            "stop" -> { job?.cancel(); job = null; ToolResults.status("stopped") }
            else -> ToolResults.error("unknown action")
        }
    }

    private fun start(driver: ScreenDriver, say: (String) -> Unit) {
        job?.cancel()
        machine = FormGuideMachine()
        job = scope.launch {
            var idle = 0
            while (true) {
                val lines = driver.readScreenDetailed()
                when (val a = machine.advance(lines)) {
                    is GuideAction.Announce -> say("[Guide] Tell the user, in simple words, to fill the field '${a.field}'. Never guess personal data. Do not read passwords or OTPs aloud.")
                    is GuideAction.Filled -> say(
                        "[Guide] The field '${a.field}' is filled. Confirm in two words" +
                            (a.next?.let { ", then tell the user the next field: '$it'" } ?: ", then tell them what to press at the end (for example Submit)") + "."
                    )
                    GuideAction.Scroll -> driver.scroll("down")
                    GuideAction.AllDone -> { say("[Guide] All fields are filled. Tell the user what to press now (for example Submit)."); return@launch }
                    GuideAction.Wait -> {}
                }
                delay(1500)
                if (++idle > 2000) return@launch
            }
        }
    }
}
