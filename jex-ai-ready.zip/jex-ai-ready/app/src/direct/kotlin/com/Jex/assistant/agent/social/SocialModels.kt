package com.Jex.assistant.agent.social

import com.Jex.assistant.agent.core.Blocker
import com.Jex.assistant.agent.core.ScreenObservation
import org.json.JSONObject

enum class Platform(val pkg: String, val label: String) { INSTAGRAM("com.instagram.android", "Instagram"), FACEBOOK("com.facebook.katana", "Facebook") }
enum class SocialAction { CREATE_POST, CREATE_REEL, CREATE_STORY, TEXT_POST }
enum class TaskMode { PUBLISH, DRAFT }
enum class TaskStatus { RUNNING, WAITING_FOR_CONFIRMATION, WAITING_FOR_USER, COMPLETED, SUBMITTED_UNVERIFIED, FAILED, CANCELLED }
enum class ControlCommand { CONFIRM, REJECT, RESUME, CANCEL, STATUS }

data class PlanStep(val name: String, val target: String?, val irreversible: Boolean = false, val expectText: String? = null)

data class TaskReport(val taskId: String, val status: TaskStatus, val message: String, val steps: Int = 0) {
    fun toJson(): JSONObject = JSONObject().put("task_id", taskId).put("status", status.name.lowercase()).put("message", message).put("steps", steps)
}

data class SocialTaskRequest(
    val platform: Platform, val action: SocialAction, val mediaUri: String?, val caption: String,
    val mode: TaskMode, val targetAccount: String?
) {
    sealed class Parsed {
        data class Ok(val request: SocialTaskRequest) : Parsed()
        data class Invalid(val reason: String) : Parsed()
    }

    companion object {
        /** Validates the model's arguments BEFORE any task exists. */
        fun parse(args: JSONObject): Parsed {
            val platform = Platform.entries.firstOrNull { it.name.equals(args.optString("platform"), true) } ?: return Parsed.Invalid("platform must be instagram or facebook")
            val action = SocialAction.entries.firstOrNull { it.name.equals(args.optString("action"), true) } ?: return Parsed.Invalid("unknown action")
            val mode = TaskMode.entries.firstOrNull { it.name.equals(args.optString("mode", "publish"), true) } ?: TaskMode.PUBLISH
            val media = args.optString("media_uri").takeIf { it.isNotBlank() }
            val caption = args.optString("caption")
            if (action != SocialAction.TEXT_POST && media == null) return Parsed.Invalid("media_uri required: ask the user to share the photo or video to Jex AI first")
            if (media != null && !media.startsWith("content://")) return Parsed.Invalid("media_uri must be a content:// URI shared to Jex AI")
            if (action == SocialAction.TEXT_POST && caption.isBlank()) return Parsed.Invalid("caption required for a text post")
            return Parsed.Ok(SocialTaskRequest(platform, action, media, caption, mode, args.optString("target_account").takeIf { it.isNotBlank() }))
        }
    }
}

/** Only content:// URIs that the user shared to Jex AI through ShareToJexActivity are acceptable. */
object MediaResolver {
    private val shared = LinkedHashSet<String>()
    @Synchronized fun register(uri: String) { shared.add(uri); while (shared.size > 20) shared.remove(shared.first()) }
    @Synchronized fun isShared(uri: String) = uri in shared
    @Synchronized fun latest(): String? = shared.lastOrNull()
}

object BlockerDetector {
    fun detect(obs: ScreenObservation): Blocker? {
        fun any(vararg k: String) = k.any { obs.has(it) }
        return when {
            any("captcha", "i'm not a robot", "verify you're human") -> Blocker.CAPTCHA
            any("two-factor", "security code", "enter the code", "confirmation code", "6-digit") -> Blocker.TWO_FACTOR
            any("suspicious", "confirm it's you", "security check", "we detected unusual") -> Blocker.SECURITY_CHECK
            any("log in", "login", "sign in") && obs.elements.any { it.isInput && (it.label.contains("password", true)) } -> Blocker.LOGIN
            any("allow access", "allow photos", "allow instagram to access") -> Blocker.PERMISSION_PROMPT
            else -> null
        }
    }
}

/** Per-platform button labels (accessibility text); easy to adjust when the apps change. */
object Selectors {
    fun createButton(p: Platform) = when (p) { Platform.INSTAGRAM -> "Create"; Platform.FACEBOOK -> "Create" }
    fun entryFor(p: Platform, a: SocialAction): List<String> = when (a) {
        SocialAction.CREATE_POST -> listOf("Post")
        SocialAction.CREATE_REEL -> listOf("Reel")
        SocialAction.CREATE_STORY -> listOf("Story")
        SocialAction.TEXT_POST -> if (p == Platform.FACEBOOK) listOf("What's on your mind") else listOf("Post")
    }
    val next = listOf("Next", "Continue")
    val captionField = listOf("Write a caption", "Write a caption...", "What's on your mind")
    val publish = listOf("Share", "Post", "Publish")
    val saveDraft = listOf("Save draft", "Save as draft")
}
