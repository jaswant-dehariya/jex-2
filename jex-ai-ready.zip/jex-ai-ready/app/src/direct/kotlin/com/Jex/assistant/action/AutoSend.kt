package com.Jex.assistant.action

import kotlinx.coroutines.delay

/** After a composer opens, tap Send for the user (they clearly asked to send). */
object AutoSend {
    suspend fun tapSend(driver: ScreenDriver = ScreenDrivers.current, whatsApp: Boolean = false, tries: Int = 12, waitMs: Long = 400): String {
        if (!driver.isAvailable()) return "composer_opened_send_not_found"
        repeat(tries) {
            delay(waitMs)
            if (whatsApp) driver.clickText("Continue to chat")
            if (driver.clickText("Send")) return "sent"
        }
        return "composer_opened_send_not_found"
    }
}
