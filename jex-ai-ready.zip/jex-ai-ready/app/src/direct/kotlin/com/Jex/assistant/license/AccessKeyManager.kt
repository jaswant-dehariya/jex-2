package com.Jex.assistant.license

import android.content.Context
import com.Jex.assistant.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

enum class LicenseStatus { NOT_CONFIGURED, NO_KEY, ACTIVE, EXPIRED, BLOCKED }

/** Pure rule: what a cached/remote answer means right now. */
object AccessKeyRules {
    fun evaluate(configured: Boolean, hasKey: Boolean, blocked: Boolean, expiresAt: Long, now: Long): LicenseStatus = when {
        !configured -> LicenseStatus.NOT_CONFIGURED
        !hasKey -> LicenseStatus.NO_KEY
        blocked -> LicenseStatus.BLOCKED
        expiresAt in 1 until now -> LicenseStatus.EXPIRED
        else -> LicenseStatus.ACTIVE
    }

    fun message(s: LicenseStatus): String = when (s) {
        LicenseStatus.NOT_CONFIGURED -> "Licensing is not configured in this build."
        LicenseStatus.NO_KEY -> "Enter your access key in Profile to use Jex AI."
        LicenseStatus.EXPIRED -> "Your access key has expired. Please renew it."
        LicenseStatus.BLOCKED -> "This access key has been blocked."
        LicenseStatus.ACTIVE -> ""
    }
}

/** Direct build only. Activates and re-checks an access key against your own backend (see docs/LICENSING.md). */
object AccessKeyManager {
    private const val FILE = "jex_license"
    private val http = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
    private val JSON = "application/json; charset=utf-8".toMediaType()
    private val _info = MutableStateFlow(LicenseInfo(active = true))
    val info: StateFlow<LicenseInfo> = _info

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private fun configured() = BuildConfig.LICENSE_BASE_URL.isNotBlank()

    private fun deviceId(ctx: Context): String {
        val sp = p(ctx)
        return sp.getString("device_id", null) ?: UUID.randomUUID().toString().also { sp.edit().putString("device_id", it).apply() }
    }

    private fun status(ctx: Context): LicenseStatus {
        val sp = p(ctx)
        return AccessKeyRules.evaluate(configured(), !sp.getString("key", "").isNullOrBlank(), sp.getBoolean("blocked", false), sp.getLong("expires", 0L), System.currentTimeMillis())
    }

    fun isActive(ctx: Context): Boolean {
        val s = status(ctx)
        // Debug builds without a backend stay usable so you can develop; release builds never do.
        if (s == LicenseStatus.NOT_CONFIGURED) return BuildConfig.DEBUG
        return s == LicenseStatus.ACTIVE
    }

    fun blockedMessage(ctx: Context): String = AccessKeyRules.message(status(ctx))

    fun refreshInfo(ctx: Context) {
        val s = status(ctx)
        val sp = p(ctx)
        _info.value = LicenseInfo(
            active = s == LicenseStatus.ACTIVE || (s == LicenseStatus.NOT_CONFIGURED && BuildConfig.DEBUG),
            plan = sp.getString("plan", "").orEmpty(), expiresAt = sp.getLong("expires", 0L),
            statusText = AccessKeyRules.message(s), blocked = s == LicenseStatus.BLOCKED,
            hasRememberedKey = !sp.getString("key", "").isNullOrBlank()
        )
    }

    private suspend fun call(ctx: Context, path: String, key: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().put("key", key).put("device_id", deviceId(ctx)).toString().toRequestBody(JSON)
            val req = Request.Builder().url(BuildConfig.LICENSE_BASE_URL.trimEnd('/') + path)
                .header("Authorization", "Bearer " + BuildConfig.LICENSE_API_KEY).post(body).build()
            http.newCall(req).execute().use { r -> if (r.isSuccessful) JSONObject(r.body?.string().orEmpty()) else JSONObject().put("valid", false).put("message", "HTTP ${r.code}") }
        } catch (ignored: Exception) { null }
    }

    private fun apply(ctx: Context, key: String, o: JSONObject) {
        p(ctx).edit()
            .putString("key", if (o.optBoolean("valid", false) || o.optBoolean("blocked", false)) key else "")
            .putString("plan", o.optString("plan"))
            .putLong("expires", o.optLong("expires_at", 0L))
            .putBoolean("blocked", o.optBoolean("blocked", false)).apply()
        refreshInfo(ctx)
    }

    /** Returns null on success, or a user-facing error. */
    suspend fun activate(ctx: Context, key: String): String? {
        if (!configured()) return "Licensing is not configured in this build."
        val o = call(ctx, "/activate", key.trim()) ?: return "Couldn't reach the licence server. Check your internet."
        if (!o.optBoolean("valid", false)) return o.optString("message").ifBlank { "That key is not valid." }
        apply(ctx, key.trim(), o)
        return null
    }

    /** Re-validates on resume; being offline keeps the cached answer until it expires. */
    suspend fun liveCheck(ctx: Context) {
        val key = p(ctx).getString("key", "").orEmpty()
        if (configured() && key.isNotBlank()) call(ctx, "/check", key)?.let { apply(ctx, key, it) }
        refreshInfo(ctx)
    }

    fun forget(ctx: Context) { p(ctx).edit().clear().apply(); refreshInfo(ctx) }
}
