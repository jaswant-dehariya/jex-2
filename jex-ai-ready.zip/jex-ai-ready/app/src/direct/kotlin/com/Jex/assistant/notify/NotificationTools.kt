package com.Jex.assistant.notify

import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.Jex.assistant.action.ToolResults
import com.Jex.assistant.data.JexPreferences
import org.json.JSONArray
import org.json.JSONObject

object NotificationTools {
    fun readRecent(ctx: Context, limit: Int, app: String?): JSONObject {
        if (!JexNotificationListener.isEnabled(ctx)) return ToolResults.status("needs_permission", "Ask the user to enable Notification access for Jex in Permissions")
        val readSensitive = JexPreferences.getBoolean(ctx, JexPreferences.Keys.READ_SENSITIVE_ALOUD, false)
        val arr = JSONArray()
        NotificationStore.recent(limit.coerceIn(1, 15), app).forEach { e ->
            val body = (if (e.messages.isNotEmpty()) e.messages.takeLast(2).joinToString(" / ") else e.text).take(200)
            val shown = if (NotificationRules.isSensitive(body)) (if (readSensitive) NotificationRules.maskSensitive(body) else "(sensitive, hidden)") else body
            arr.put(JSONObject().put("key", e.key).put("app", e.appLabel).put("from", e.sender).put("text", shown).put("can_reply", e.hasReplyAction))
        }
        return JSONObject().put("status", "ok").put("notifications", arr)
    }

    fun toggle(ctx: Context, on: Boolean): JSONObject {
        JexPreferences.putBoolean(ctx, JexPreferences.Keys.READ_NOTIFICATIONS, on)
        return ToolResults.status(if (on) "on" else "off")
    }

    /** Sends a reply through the notification's own RemoteInput action. */
    fun reply(ctx: Context, key: String, text: String): JSONObject {
        val action = NotificationStore.replyAction(key) ?: return ToolResults.status("no_reply_action", "This notification has no inline reply; open the app and type instead")
        val remote = action.remoteInputs?.firstOrNull() ?: return ToolResults.status("no_reply_action")
        return try {
            val intent = Intent()
            val results = Bundle().apply { putCharSequence(remote.resultKey, text) }
            RemoteInput.addResultsToIntent(arrayOf(remote), intent, results)
            action.actionIntent.send(ctx, 0, intent)
            ToolResults.status("sent")
        } catch (e: PendingIntent.CanceledException) {
            ToolResults.status("failed", "The notification was dismissed")
        }
    }
}
