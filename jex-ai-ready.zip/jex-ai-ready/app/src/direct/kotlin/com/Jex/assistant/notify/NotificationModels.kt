package com.Jex.assistant.notify

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class NotificationEvent(
    val id: Int,
    val key: String,
    val packageName: String,
    val appLabel: String,
    val sender: String,
    val text: String,
    val messages: List<String>,
    val postedAt: Long,
    val category: String?,
    val hasReplyAction: Boolean
)

/** Pure filtering and masking rules (unit-tested without Android). */
object NotificationRules {
    private val otpWords = listOf("otp", "one time password", "one-time password", "verification code", "passcode", "password", "cvv", "pin ", "bank", "a/c", "account", "debited", "credited", "upi")
    private val digits = Regex("\\b\\d{4,8}\\b")

    fun isSensitive(text: String): Boolean {
        val l = text.lowercase()
        return otpWords.any { l.contains(it) } && (digits.containsMatchIn(text) || l.contains("otp") || l.contains("password"))
    }

    /** "Your OTP is 482913" -> "OTP aaya hai" style; digits are never exposed. */
    fun maskSensitive(text: String): String =
        if (text.lowercase().contains("otp") || text.lowercase().contains("verification code")) "OTP aaya hai" else "Ek sensitive message aaya hai"

    fun shouldSkip(
        ongoing: Boolean, foregroundService: Boolean, groupSummary: Boolean, category: String?,
        packageName: String, ownPackage: String
    ): Boolean {
        if (ongoing || foregroundService || groupSummary) return true
        if (packageName == ownPackage) return true
        if (category == "transport" || category == "progress" || category == "call") return true
        return false
    }

    fun isDuplicate(last: NotificationEvent?, next: NotificationEvent, windowMs: Long = 2000): Boolean =
        last != null && last.packageName == next.packageName && last.sender == next.sender && last.text == next.text &&
            next.postedAt - last.postedAt < windowMs

    /** Allow/deny lists are comma separated package names. Deny wins; empty allow = everyone. */
    fun appAllowed(pkg: String, allowCsv: String, denyCsv: String = ""): Boolean {
        val deny = denyCsv.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (pkg in deny) return false
        val allow = allowCsv.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        return allow.isEmpty() || pkg in allow
    }
}

object NotificationStore {
    const val CAPACITY = 50
    private val buffer = ArrayDeque<NotificationEvent>()
    private val _events = MutableStateFlow<List<NotificationEvent>>(emptyList())
    val events: StateFlow<List<NotificationEvent>> = _events
    private val replyActions = HashMap<String, android.app.Notification.Action>()

    @Synchronized
    fun add(e: NotificationEvent, reply: android.app.Notification.Action? = null): Boolean {
        if (NotificationRules.isDuplicate(buffer.lastOrNull(), e)) return false
        buffer.addLast(e)
        while (buffer.size > CAPACITY) { val old = buffer.removeFirst(); replyActions.remove(old.key) }
        if (reply != null) replyActions[e.key] = reply
        _events.value = buffer.toList()
        return true
    }

    @Synchronized fun recent(limit: Int, appFilter: String? = null): List<NotificationEvent> =
        buffer.toList().asReversed().filter { appFilter.isNullOrBlank() || it.appLabel.contains(appFilter, true) || it.packageName.contains(appFilter, true) }.take(limit)

    @Synchronized fun find(key: String): NotificationEvent? = buffer.firstOrNull { it.key == key }
    @Synchronized fun replyAction(key: String) = replyActions[key]
    @Synchronized fun clear() { buffer.clear(); replyActions.clear(); _events.value = emptyList() }
}
