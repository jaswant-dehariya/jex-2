package com.Jex.assistant.forge

import com.Jex.assistant.voice.GeminiTextClient
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeStageDetectorTest {
    @Test fun emptyIsReading() = assertEquals(ForgeStage.READING, ForgeStageDetector.detect(""))
    @Test fun headOnlyIsReading() = assertEquals(ForgeStage.READING, ForgeStageDetector.detect("<!DOCTYPE html><html><head><script src=\"gsap.min.js\"></script></head>"))
    @Test fun bodyIsStructure() = assertEquals(ForgeStage.STRUCTURE, ForgeStageDetector.detect("<html><head></head><body><header>x</header>"))
    @Test fun manyBlocksIsStyling() = assertEquals(ForgeStage.STYLING, ForgeStageDetector.detect("<body><header>a</header><section>b</section>"))
    @Test fun canvasIsVisuals() = assertEquals(ForgeStage.VISUALS, ForgeStageDetector.detect("<body><header>a</header><section><canvas></canvas></section>"))
    @Test fun gsapInBodyIsMotion() = assertEquals(ForgeStage.MOTION, ForgeStageDetector.detect("<body><section>a</section><section><canvas></canvas><script>gsap.from('.a',{})</script>"))
    @Test fun closingHtmlIsFinalizing() = assertEquals(ForgeStage.FINALIZING, ForgeStageDetector.detect("<html><body></body></html>"))
    @Test fun progressCapped() = assertTrue(ForgeStageDetector.progress(ForgeStage.FINALIZING, 200000) <= 0.98f)
}

class SseParserTest {
    @Test fun extractsText() {
        val line = "data: " + JSONObject().put("candidates", JSONArray().put(JSONObject().put("content", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "<html>")))))).toString()
        assertEquals("<html>", SseParser.extractText(line))
    }
    @Test fun skipsThoughts() {
        val parts = JSONArray().put(JSONObject().put("text", "hmm").put("thought", true)).put(JSONObject().put("text", "ok"))
        val line = "data: " + JSONObject().put("candidates", JSONArray().put(JSONObject().put("content", JSONObject().put("parts", parts)))).toString()
        assertEquals("ok", SseParser.extractText(line))
    }
    @Test fun doneAndGarbageIgnored() { assertNull(SseParser.extractText("data: [DONE]")); assertNull(SseParser.extractText("data: {nope")); assertNull(SseParser.extractText("event: x")) }
    @Test fun errorExtracted() {
        val line = "data: " + JSONObject().put("error", JSONObject().put("status", "UNAVAILABLE").put("message", "overloaded")).toString()
        assertTrue(SseParser.extractError(line)!!.contains("UNAVAILABLE"))
    }
    @Test fun finishReason() {
        val line = "data: " + JSONObject().put("candidates", JSONArray().put(JSONObject().put("finishReason", "RECITATION"))).toString()
        assertEquals("RECITATION", SseParser.extractFinishReason(line))
    }
}

class ForgeHtmlTest {
    @Test fun stripsFences() = assertEquals("<html></html>", ForgeHtml.stripFences("```html\n<html></html>\n```"))
    @Test fun repairClosesTags() {
        val r = ForgeHtml.repairTruncated("<html><body><script>var a=1;")
        assertTrue(r.contains("</script>") && r.contains("</body>") && r.contains("</html>"))
    }
    @Test fun repairDropsDanglingTag() = assertFalse(ForgeHtml.repairTruncated("<html><body><div cla").contains("<div cla"))
    @Test fun safetyNetIdempotent() {
        val once = ForgeHtml.withSafetyNet("<html><body>x</body></html>")
        assertEquals(once, ForgeHtml.withSafetyNet(once))
        assertTrue(once.contains(ForgeHtml.SAFETY_MARKER))
    }
    @Test fun looksLikeHtml() { assertTrue(ForgeHtml.looksLikeHtml("<!DOCTYPE html><html>")); assertFalse(ForgeHtml.looksLikeHtml("sorry I cannot")) }
}

class ForgeIntentTest {
    @Test fun detectsBuild() { assertNotNull(ForgeIntent.extract("build me a website for my cafe")); assertNotNull(ForgeIntent.extract("ek cafe ki website banao")) }
    @Test fun ignoresQuestions() = assertNull(ForgeIntent.extract("how does a website work?"))
    @Test fun needsBothParts() { assertNull(ForgeIntent.extract("tell me about websites")); assertNull(ForgeIntent.extract("make me a sandwich")) }
}

class ForgeSectionsTest {
    @Test fun usesIdThenHeading() {
        val html = "<section id=\"hero-area\"><h1>x</h1></section><section><h2>Our Menu</h2></section><section></section>"
        assertEquals(listOf("Hero Area", "Our Menu", "Section 3"), ForgeSections.extract(html))
    }
}

class ModelPickTest {
    private fun m(name: String, vararg methods: String) = JSONObject().put("name", "models/$name").put("supportedGenerationMethods", JSONArray(methods.toList()))
    @Test fun prefersPlainFlash() {
        val arr = JSONArray().put(m("gemini-x-live", "generateContent")).put(m("gemini-pro", "generateContent")).put(m("gemini-3-flash", "generateContent"))
        assertEquals("gemini-3-flash", GeminiTextClient.pickModel(arr))
    }
    @Test fun fallsBackToAnyGenerator() = assertEquals("gemini-pro", GeminiTextClient.pickModel(JSONArray().put(m("gemini-pro", "generateContent"))))
    @Test fun noneIsNull() = assertNull(GeminiTextClient.pickModel(JSONArray().put(m("embed", "embedContent"))))
}
