package com.Jex.assistant.voice

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LanguageDetectorTest {
    @Test fun blankIsUnknown() = assertEquals(DetectedLanguage.UNKNOWN, LanguageDetector.detect("  "))
    @Test fun devanagariIsHindi() = assertEquals(DetectedLanguage.HINDI, LanguageDetector.detect("आप कैसे हैं"))
    @Test fun hinglish() = assertEquals(DetectedLanguage.HINGLISH, LanguageDetector.detect("kya haal hai yaar"))
    @Test fun english() = assertEquals(DetectedLanguage.ENGLISH, LanguageDetector.detect("what is the weather today in London"))
    @Test fun shortEnglishStaysEnglish() = assertEquals(DetectedLanguage.ENGLISH, LanguageDetector.detect("open camera"))
    @Test fun shortHinglishOneHit() = assertEquals(DetectedLanguage.HINGLISH, LanguageDetector.detect("camera kholo bhai"))
}

class ConversationMemoryTest {
    @Test fun emptyRecapIsNull() = assertNull(ConversationMemory().recap())
    @Test fun recapLabelsSpeakers() {
        val m = ConversationMemory()
        m.add(ConversationMemory.Role.USER, "hello")
        m.add(ConversationMemory.Role.ASSISTANT, "hi there")
        val r = m.recap()!!
        assertTrue(r.contains("User: hello"))
        assertTrue(r.contains("You: hi there"))
    }
    @Test fun keepsOnlyTwelveTurns() {
        val m = ConversationMemory()
        for (i in 1..30) m.add(if (i % 2 == 0) ConversationMemory.Role.ASSISTANT else ConversationMemory.Role.USER, "turn$i")
        val r = m.recap()!!
        assertFalse(r.contains("turn1\n"))
        assertTrue(r.contains("turn30"))
    }
    @Test fun recapCapped() {
        val m = ConversationMemory()
        for (i in 1..12) m.add(if (i % 2 == 0) ConversationMemory.Role.ASSISTANT else ConversationMemory.Role.USER, "x".repeat(500))
        assertTrue(m.recap()!!.length <= ConversationMemory.RECAP_MAX)
    }
    @Test fun clearEmpties() { val m = ConversationMemory(); m.add(ConversationMemory.Role.USER, "a"); m.clear(); assertTrue(m.isEmpty()) }
}

class ToolCallDeduplicatorTest {
    @Test fun secondTimeRejected() { val d = ToolCallDeduplicator(); assertTrue(d.firstTime("a")); assertFalse(d.firstTime("a")) }
    @Test fun boundedCapacity() {
        val d = ToolCallDeduplicator(3)
        listOf("a", "b", "c", "d").forEach { d.firstTime(it) }
        assertTrue(d.firstTime("a")) // evicted, so new again
    }
    @Test fun emptyIdAlwaysNew() { val d = ToolCallDeduplicator(); assertTrue(d.firstTime("")); assertTrue(d.firstTime("")) }
}

@OptIn(ExperimentalCoroutinesApi::class)
class EchoGuardTest {
    @Test fun mutesWhilePlayingAndTailThenReleases() {
        val ts = TestScope()
        var now = 0L
        EchoGuard.reset()
        EchoGuard.scope = ts
        EchoGuard.clock = { now }
        EchoGuard.notifyPlaybackStarted()
        assertTrue(EchoGuard.isMicMuted())
        EchoGuard.notifyPlaybackStopped()
        assertTrue(EchoGuard.isMicMuted()) // inside the tail
        now = 460; ts.advanceTimeBy(460); ts.runCurrent()
        assertFalse(EchoGuard.isMicMuted())
    }
    @Test fun overlappingPlaybacksCounted() {
        val ts = TestScope(); EchoGuard.reset(); EchoGuard.scope = ts
        EchoGuard.notifyPlaybackStarted(); EchoGuard.notifyPlaybackStarted()
        EchoGuard.notifyPlaybackStopped()
        assertEquals(1, EchoGuard.activeCount())
        assertTrue(EchoGuard.isMicMuted())
    }
}

class VoiceLatencyTrackerTest {
    @Test fun deltasAndOrdering() {
        var t = 0L
        val tr = VoiceLatencyTracker { t }
        t = 100; tr.mark(VoiceLatencyTracker.Mark.USER_SPEECH_END)
        t = 350; tr.mark(VoiceLatencyTracker.Mark.FIRST_AUDIO)
        assertEquals(250L, tr.toFirstAudio())
        t = 400; tr.mark(VoiceLatencyTracker.Mark.FIRST_TRANSCRIPT) // out of order: ignored
        assertNull(tr.delta(VoiceLatencyTracker.Mark.USER_SPEECH_END, VoiceLatencyTracker.Mark.FIRST_TRANSCRIPT))
    }
    @Test fun resetClears() {
        val tr = VoiceLatencyTracker { 5 }
        tr.mark(VoiceLatencyTracker.Mark.USER_SPEECH_END); tr.reset()
        assertNull(tr.toFirstAudio())
    }
}

class IdentityPromptTest {
    @Test fun namesAndDeveloper() {
        val p = IdentityPrompt.build()
        assertTrue(p.contains("Jex AI"))
        assertTrue(p.contains("जसवंत डेहरिया"))
        assertTrue(IdentityPrompt.FILLER_WORDS.size >= 10)
    }
    @Test fun roastPolicyForbidsSensitiveTargets() {
        val t = RoastPolicy.text()
        assertTrue(t.contains("religion") && t.contains("caste") && t.contains("disability"))
        assertTrue(t.contains("bas"))
    }
}

class LiveAudioMathTest {
    @Test fun silenceIsZero() = assertEquals(0f, LiveAudioIO.rms(ByteArray(100)), 0.0001f)
    @Test fun loudIsHigh() {
        val b = ByteArray(200)
        for (i in 0 until 100) { b[i * 2] = 0xFF.toByte(); b[i * 2 + 1] = 0x7F }
        assertTrue(LiveAudioIO.rms(b) > 0.9f)
    }
    @Test fun notNullMapping() { assertNotNull(VoiceSessionManager.mapVoice("puck")); assertEquals("Aoede", VoiceSessionManager.mapVoice("nope")) }
}
