# org.json is part of Android; keep model classes used via reflection-free code only.
-keep class org.json.** { *; }
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
# JS bridge exposed to the Forge WebView (only these three methods).
-keepclassmembers class com.Jex.assistant.ui.screens.forge.ForgeJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
# Accessibility / notification services are referenced from the manifest.
-keep class com.Jex.assistant.action.JexAccessibilityService { *; }
-keep class com.Jex.assistant.notify.JexNotificationListener { *; }
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
